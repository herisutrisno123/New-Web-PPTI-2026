import React from 'react';
import { Globe, Database, Award, Leaf, Users, Layout, Target, BookOpen, ShieldCheck, TrendingUp, Trees, HeartPulse, ClipboardCheck, ClipboardList, Smartphone } from 'lucide-react';

export interface Article {
  id: string;
  title: string;
  category: string;
  description: string;
  content: string;
  image: string;
  stats: string;
  icon: React.ReactNode;
  isGraphic?: boolean;
}

// SVG constants used in articles
const dmmImageUri = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500"><rect width="800" height="500" fill="%23f8fafc"/><g transform="translate(60, 100)"><rect x="0" y="220" width="70" height="150" fill="%230038a8"/><rect x="85" y="180" width="70" height="190" fill="%230038a8"/><rect x="170" y="110" width="70" height="260" fill="%230038a8"/><rect x="255" y="40" width="70" height="330" fill="%230038a8"/><path d="M120 180 l80 80 l180 -180" fill="none" stroke="%230038a8" stroke-width="45" stroke-linecap="round" stroke-linejoin="round"/><path d="M120 180 l80 80 l180 -180" fill="none" stroke="%23f8fafc" stroke-width="15" stroke-linecap="round" stroke-linejoin="round"/></g><text x="400" y="150" font-family="Arial, sans-serif" font-weight="900" font-size="62" fill="%230038a8">DATA</text><text x="400" y="225" font-family="Arial, sans-serif" font-weight="900" font-size="62" fill="%230038a8">MANAGEMENT</text><text x="400" y="300" font-family="Arial, sans-serif" font-weight="900" font-size="62" fill="%230038a8">MATURITY</text><text x="400" y="375" font-family="Arial, sans-serif" font-weight="900" font-size="62" fill="%230038a8">ASSESSMENT</text></svg>`;

const akdLogoUri = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 650"><rect width="600" height="650" fill="white"/><g transform="translate(150, 40)"><path d="M128,4c-62.4,0-113,50.6-113,113c0,16.5,3.6,32.2,10.1,46.3l-18.7,18.7c-8.3,8.3-8.3,21.8,0,30.1l28.6,28.6c4.1,4.1,9.7,6.4,15.5,6.4h15.9v92.4 c0,14,11.4,25.4,25.4,25.4h161.4c14,0,25.4-11.4,25.4-25.4V92.2c0-48.7-39.5-88.2-88.2-88.2H128z M128,34.2h92.4c30,0,54.4,24.4,54.4,54.4v220.2c0,2.1-1.7,3.8-3.8,3.8H108 c-2.1,0-3.8-1.7-3.8-3.8V210.6h15.8c10.4,0,20.2-4,27.5-11.3l32.5-32.5l34.4,34.4c3.1,3.1,7.4,4.9,11.9,4.9s8.8-1.8,11.9-4.9l71.3-71.3 c6.6-6.6,6.6-17.2,0-23.8s-17.2-6.6-23.8,0l-59.4,59.4l-34.4-34.4c-3.1-3.1-7.4-4.9-11.9-4.9s-8.8,1.8-11.9,4.9l-44.4,44.4h-10.3v-65.3 h-30.1v88.5H83.3v-88.5H53.1v88.5H23v-88.5h-3.6V97.2h88.2c9.2,0,16.6,7.4,16.6,16.6s-7.4,16.6-16.6,16.6H88v30.1h17.1c9.2,0,16.6,7.4,16.6,16.6 s-7.4,16.6-16.6,16.6H88v30.1h17.1c9.2,0,16.6,7.4,16.6,16.6s-7.4,16.6-16.6,16.6H62.2c-8.3,0-15.5-6.4-15.8-14.7V121.2h30.1V34.2H128z" fill="%23003366"/><g transform="translate(100, 100)"><rect x="30" y="0" width="28" height="28" fill="%23003366"/><rect x="0" y="50" width="28" height="28" fill="%23003366"/><rect x="30" y="100" width="28" height="28" fill="%23003366"/></g><g transform="translate(180, 160)"><rect x="0" y="40" width="30" height="120" fill="%23003366"/><rect x="40" y="0" width="30" height="160" fill="%23003366"/><rect x="80" y="-40" width="30" height="200" fill="%23003366"/><path d="M-60,70 L-10,120 L130,10" fill="none" stroke="%23003366" stroke-width="28" stroke-linejoin="round" stroke-linecap="round"/><path d="M100,10 L130,10 L130,40" fill="none" stroke="%23003366" stroke-width="28" stroke-linejoin="round" stroke-linecap="round"/></g></g><text x="300" y="500" font-family="Arial, sans-serif" font-weight="900" font-size="64" text-anchor="middle" fill="%23003366">KOMPETENSI</text><text x="300" y="580" font-family="Arial, sans-serif" font-weight="900" font-size="88" text-anchor="middle" fill="%23003366">DIGITAL</text></svg>`;

export const articles: Article[] = [
  {
    id: "ksb-app",
    title: "Aplikasi Kawasan Sejahtera Berkelanjutan",
    category: "Kawasan",
    description: "Platform digital terintegrasi untuk memantau, mengelola, dan mengoptimalkan inisiatif pembangunan kawasan berkelanjutan secara real-time.",
    content: `Aplikasi Kawasan Sejahtera Berkelanjutan (KSB App) merupakan tulang punggung digital dari inisiatif transformasi kawasan yang diusung oleh PPTI. Aplikasi ini dirancang untuk mensinkronisasikan seluruh pilar KSB—Layanan Publik, Lingkungan, Ekonomi, dan Sosial—dalam satu ekosistem data yang terpadu.

Melalui KSB App, pengelola kawasan dan warga dapat berinteraksi secara lebih dinamis melalui fitur-fitur unggulan berikut:

1. Unified Dashboard Monitoring:
Menyediakan visualisasi data real-time mengenai performa kawasan, mulai dari tingkat penggunaan energi terbarukan, indeks kualitas udara, hingga status capaian digitalisasi UMKM lokal. Dashboard ini memungkinkan pengambilan keputusan berbasis data (data-driven decision making) yang lebih akurat.

2. Mobile Public Service Hub:
Mengintegrasikan seluruh layanan administrasi kependudukan dan perizinan dalam genggaman. Warga dapat mengajukan permohonan, memantau status dokumen, dan menerima notifikasi penyelesaian layanan tanpa harus hadir secara fisik, meningkatkan efisiensi birokrasi hingga 60%.

3. Citizen Response System:
Fitur pelaporan dua arah yang memungkinkan warga melaporkan kendala infrastruktur atau lingkungan (seperti lampu jalan mati atau tumpukan sampah) secara langsung. Laporan yang masuk akan otomatis diteruskan ke unit kerja terkait dengan pelacakan status yang transparan bagi pelapor.

4. Ekonomi Lokal & Marketplace Inklusif:
Wadah khusus bagi UMKM di dalam kawasan untuk memamerkan produk dan jasa mereka. Fitur ini memfasilitasi transaksi non-tunai dan memperluas akses pasar bagi pelaku usaha lokal, serta menyediakan data analitik penjualan untuk pengembangan bisnis mereka.

Aplikasi KSB bukan hanya sebuah perangkat lunak, melainkan perwujudan dari komitmen PPTI untuk menciptakan tata kelola kawasan yang lebih cerdas, inklusif, dan berkelanjutan melalui kedaulatan teknologi informasi.`,
    icon: <Smartphone className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80&w=800",
    stats: "Solusi Digital Terpadu",
    isGraphic: false
  },
  {
    id: "ksb-indikator-sasaran-target",
    title: "Indikator Pilar Utama Kawasan Sejahtera Berkelanjutan",
    category: "Kawasan",
    description: "Rincian teknis indikator kunci, sasaran strategis, dan target capaian untuk mewujudkan transformasi kawasan yang terukur dan berdaya saing.",
    content: `Keberhasilan program Kawasan Sejahtera Berkelanjutan (KSB) diukur melalui parameter yang ketat dan berorientasi pada hasil. PPTI telah merancang daftar indikator pilar utama beserta sasaran dan target capaian yang harus dipenuhi oleh kawasan yang mengadopsi inisiatif ini.

Berikut adalah rincian target transformasi untuk masing-masing pilar:

1. Indikator Layanan Publik Terpadu
Untuk mewujudkan tata kelola birokrasi yang ramping dan responsif, pilar ini dibagi menjadi tiga area fokus utama:

A. Digitalisasi Layanan
• Indikator: Persentase layanan administrasi yang dapat diselesaikan secara end-to-end melalui platform digital.
• Sasaran: Memberikan kemudahan akses layanan 24/7 bagi warga tanpa perlu kehadiran fisik ke kantor dinas.
• Target Capaian: 100% layanan utama kawasan terdigitalisasi penuh dalam jangka waktu 3 tahun.

B. Transparansi Birokrasi
• Indikator: Ketersediaan sistem pelacakan (tracking) permohonan dan publikasi standar waktu layanan (SLA) secara real-time.
• Sasaran: Menghilangkan ketidakpastian proses dan mencegah praktik pungutan liar melalui pengawasan publik.
• Target Capaian: Skor Indeks Kepuasan Masyarakat (IKM) terhadap transparansi layanan mencapai minimal 85/100.

C. Koordinasi Lintas Instansi
• Indikator: Tingkat interoperabilitas data antar-instansi melalui integrasi API atau Bus Data Kawasan.
• Sasaran: Efisiensi pengolahan data melalui prinsip "Single Source of Truth" (Satu Data) untuk menghindari duplikasi input.
• Target Capaian: Pengurangan waktu pemrosesan administrasi lintas instansi sebesar 50% dibandingkan metode konvensional.

2. Indikator Lingkungan Berkelanjutan
Pilar ini berfokus pada daya dukung ekosistem kawasan melalui empat indikator teknis utama:

A. Energi Terbarukan
• Indikator: Persentase penggunaan energi bersih (solar, angin, biomassa) pada fasilitas publik dan industri kawasan.
• Sasaran: Menurunkan ketergantungan pada energi fosil and menekan emisi gas rumah kaca di tingkat lokal.
• Target Capaian: Pemanfaatan energi terbarukan mencapai 40% dari total bauran energi kawasan dalam 5 tahun.

B. Pengelolaan Sampah (Circular Economy)
• Indikator: Rasio volume sampah yang didaur ulang dibandingkan dengan total volume sampah yang dihasilkan kawasan.
• Sasaran: Mewujudkan kawasan "Zero Waste" melalui sistem pemilahan digital dan pemberemberdayaan ekonomi sirkular masyarakat.
• Target Capaian: 70% sampah terkelola secara mandiri and terintegrasi dengan platform monitoring limbah cerdas.

C. Konservasi Air
• Indikator: Efisiensi penggunaan air bersih dan implementasi teknologi pemanenan air hujan (rainwater harvesting).
• Sasaran: Menjaga stabilitas air tanah dan menjamin keberlanjutan pasokan air bersih bagi seluruh warga kawasan.
• Target Capaian: Penurunan pemborosan air sebesar 20% melalui sistem Smart Water Metering and konservasi digital.

D. Mitigasi Perubahan Iklim
• Indikator: Luas Ruang Terbuka Hijau (RTH) yang dipantau secara digital dan jumlah sensor kualitas udara kawasan.
• Sasaran: Memperkuat ketahanan kawasan terhadap dampak cuaca ekstrem and meningkatkan standar kualitas udara perkotaan.
• Target Capaian: Penambahan 15% area hijau kawasan dan cakupan 100% sensor kualitas udara di titik strategis.

3. Indikator Ekonomi Inklusif
Pilar ini memastikan pertumbuhan ekonomi digital menyentuh seluruh lapisan masyarakat melalui empat fokus utama:

A. Pemberdayaan UMKM
• Indikator: Jumlah UMKM lokal yang terdaftar dan aktif bertransaksi dalam ekosistem e-commerce kawasan.
• Sasaran: Akselerasi transformasi digital pelaku usaha mikro untuk memperluas jangkauan pasar nasional.
• Target Capaian: 80% UMKM di kawasan memiliki profil digital dan menggunakan sistem pembayaran non-tunai.

B. Ekonomi Kreatif
• Indikator: Ketersediaan Creative Hub (ruang kolaborasi) dan jumlah produk intelektual lokal yang terproteksi secara digital.
• Sasaran: Mendorong inovasi produk berbasis kreativitas lokal sebagai pendorong ekonomi baru yang unik.
• Target Capaian: Pertumbuhan sektor industri kreatif lokal sebesar 25% melalui fasilitasi ekosistem pasar digital.

C. Akses Keuangan (Financial Inclusion)
• Indikator: Rasio masyarakat dan pelaku usaha yang memiliki akses ke layanan perbankan atau platform fintech resmi.
• Sasaran: Menghilangkan hambatan akses permodalan bagi warga di pelosok kawasan melalui solusi teknologi keuangan.
• Target Capaian: Inklusi keuangan mencapai 95% dari total populasi produktif di dalam kawasan.

D. Lapangan Kerja Hijau (Green Jobs)
• Indikator: Jumlah serapan tenaga kerja baru pada sektor manajemen lingkungan, energi terbarukan, dan ekonomi sirkular.
• Sasaran: Menciptakan lapangan kerja yang berkelanjutan dan berkontribusi langsung pada kelestarian ekosistem.
• Target Capaian: Terciptanya minimal 20% lapangan kerja baru yang berbasis pada industri ramah lingkungan (Green Tech).

4. Indikator Kehidupan Sosial
Pilar ini bertujuan meningkatkan kualitas hidup dan harmoni masyarakat melalui lima area transformasi sosial:

A. Pendidikan Digital (E-Learning)
• Indikator: Tingkat penetrasi platform pembelajaran daring dan jumlah sertifikasi kompetensi digital warga.
• Sasaran: Menjamin akses pendidikan berkualitas yang inklusif tanpa batas ruang dan waktu.
• Target Capaian: 90% generasi muda di kawasan memiliki sertifikasi kompetensi digital dasar yang diakui.

B. Kesehatan Terintegrasi (E-Health)
• Indikator: Cakupan penggunaan layanan telemedicine dan tingkat digitalisasi rekam medis warga kawasan.
• Sasaran: Mempercepat respon medis, efisiensi diagnosis, dan pemerataan akses konsultasi dokter spesialis.
• Target Capaian: Layanan kesehatan digital dapat diakses oleh 100% warga di seluruh node kawasan tanpa hambatan geografis.

C. Pelestarian Budaya Digital
• Indikator: Jumlah aset budaya, tradisi, dan sejarah lokal yang terdokumentasi dalam format digital interaktif.
• Sasaran: Menjaga identitas unik kearifan lokal agar tetap lestari dan relevan di tengah arus globalisasi.
• Target Capaian: Digitalisasi 100% situs bersejarah dan tradisi luhur kawasan sebagai aset edukasi dan pariwisata digital.

D. Partisipasi Masyarakat
• Indikator: Indeks keaktifan warga dalam platform musyawarah digital dan sistem pelaporan kendala lingkungan kawasan.
• Sasaran: Meningkatkan keterlibatan demokratis warga dalam proses pengambilan keputusan pembangunan kawasan.
• Target Capaian: 70% kebijakan tingkat kawasan diputuskan berdasarkan masukan data transparan dari aspirasi digital warga.

E. Solidaritas Sosial (Digital Gotong Royong)
• Indikator: Volume bantuan sosial atau transaksi gotong royong yang disalurkan melalui platform komunitas digital.
• Sasaran: Memperkuat jaring pengaman sosial berbasis komunitas melalui efisiensi koordinasi teknologi informasi.
• Target Capaian: Terbentuknya ekosistem bantuan mandiri komunitas yang aktif 24/7 di setiap unit lingkungan kawasan.

Daftar indikator, sasaran, dan target capaian ini menjadi standar emas (gold standard) bagi PPTI dalam melakukan pendampingan dan evaluasi kawasan. Dengan target yang jelas, transformasi digital di Indonesia tidak lagi sekadar jargon, melainkan sebuah gerakan nyata menuju kesejahteraan yang berkelanjutan.`,
    icon: <ClipboardList className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1518770611048-43b20b8a218d?auto=format&fit=crop&q=80&w=800",
    stats: "Target Transformasi 2030",
    isGraphic: false
  },
  {
    id: "ksb-sosial-digital",
    title: "Kehidupan Sosial Digital",
    category: "Kawasan",
    description: "Membangun harmoni, solidaritas, dan partisipasi aktif masyarakat melalui integrasi teknologi informasi dalam layanan dasar sosial.",
    content: `Kehidupan Sosial Digital merupakan "ruh" dari inisiatif Kawasan Sejahtera Berkelanjutan (KSB). PPTI percaya bahwa teknologi tidak boleh menciptakan jarak sosial, melainkan harus menjadi perekat yang memperkuat hubungan antarwarga dan meningkatkan kualitas hidup secara holistik.

Pilar Kehidupan Sosial Digital berfokus pada empat area transformasi utama:

1. Kesehatan Digital (Telemedicine & E-Health):
Memastikan akses layanan kesehatan yang berkualitas bagi warga di pelosok kawasan melalui platform konsultasi jarak jauh. PPTI mendorong integrasi data rekam medis kawasan yang aman agar penanganan medis dapat dilakukan secara lebih cepat, akurat, dan merata.

2. Pendidikan Inklusif & Literasi Digital:
Membangun infrastruktur pembelajaran daring yang dapat diakses oleh semua lapisan masyarakat, mulai dari usia dini hingga lansia. Fokusnya adalah memberikan keterampilan praktis yang relevan dengan ekonomi masa depan, sekaligus membekali warga dengan etika berinternet (netiket) yang sehat.

3. Pelestarian Budaya Lokal:
Digitalisasi aset budaya, tradisi, dan sejarah kawasan agar tetap lestari dan dikenal luas. Melalui media digital, identitas unik setiap kawasan dapat menjadi daya tarik global tanpa kehilangan nilai asli kearifan lokalnya.

4. Solidaritas & Partisipasi Warga:
Membangun platform "Community Digital Hub" sebagai wadah gotong royong modern. Warga dapat saling membantu dalam kegiatan sosial, melaporkan kendala di lingkungan, hingga melakukan musyawarah kawasan secara transparan dan demokratis.

Melalui pilar Kehidupan Sosial Digital, PPTI memastikan bahwa revolusi teknologi informasi membawa manfaat kemanusiaan yang nyata, mewujudkan masyarakat yang tidak hanya cerdas secara digital, tetapi juga kaya secara nilai sosial dan budaya.`,
    icon: <Users className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&q=80&w=800",
    stats: "Masyarakat Berdaya",
    isGraphic: false
  },
  {
    id: "ksb-lingkungan-berkelanjutan",
    title: "Lingkungan Berkelanjutan Digital",
    category: "Kawasan",
    description: "Pemanfaatan teknologi untuk pelestarian ekosistem, pengelolaan energi terbarukan, dan mitigasi dampak perubahan iklim di tingkat kawasan.",
    content: `Lingkungan Berkelanjutan Digital merupakan manifestasi dari komitmen PPTI terhadap keberlangsungan bumi di tengah kemajuan teknologi. Kami percaya bahwa digitalisasi tidak boleh menjadi beban bagi lingkungan, melainkan harus menjadi instrumen utama dalam pelestariannya.

Melalui pilar ini, PPTI mendorong kawasan-kawasan di Indonesia untuk mengadopsi solusi teknologi hijau (Green Tech) yang mencakup:

1. Manajemen Energi Pintar (Smart Energy):
Penerapan sensor Internet of Things (IoT) untuk memantau and mengoptimalkan penggunaan energi di fasilitas publik and industri. Hal ini mencakup penggunaan sistem penerangan jalan otomatis yang hemat energi hingga integrasi sumber energi terbarukan (seperti panel surya) ke dalam grid listrik lokal yang dikelola secara digital.

2. Tata Kelola Limbah Berbasis Data:
Digitalisasi rantai pasok pengelolaan sampah, mulai dari pemantauan volume tempat sampah secara real-time hingga platform aplikasi yang menghubungkan warga dengan unit bank sampah terdekat. Data yang dihasilkan memungkinkan pemerintah kawasan merancang strategi pengelolaan limbah yang jauh lebih efektif dan minim emisi.

3. Mitigasi & Adaptasi Perubahan Iklim:
Penggunaan sistem peringatan dini (Early Warning System) berbasis data cuaca dan sensor lingkungan untuk mendeteksi potensi bencana alam. Selain itu, PPTI mendukung penggunaan dashboard lingkungan kawasan yang memantau kualitas udara dan air secara publik sebagai bentuk transparansi ekologis.

Dengan menyinergikan teknologi informasi dan pelestarian alam, pilar Lingkungan Berkelanjutan Digital memastikan bahwa pembangunan kawasan tetap selaras dengan daya dukung ekosistem, demi masa depan generasi mendatang yang lebih hijau dan sehat.`,
    icon: <Leaf className="text-green-600" size={32} />,
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=800",
    stats: "Teknologi Hijau",
    isGraphic: false
  },
  {
    id: "ksb-ekonomi-inklusif",
    title: "Ekonomi Inklusif Digital",
    category: "Kawasan",
    description: "Mendorong pertumbuhan ekonomi yang merata dan membuka peluang bagi seluruh lapisan masyarakat melalui pemberdayaan UMKM berbasis digital.",
    content: `Ekonomi Inklusif Digital adalah pilar fundamental dalam membangun Kawasan Sejahtera Berkelanjutan (KSB). PPTI berkomitmen untuk memastikan bahwa kemajuan teknologi tidak meninggalkan siapa pun, melainkan menjadi jembatan bagi setiap individu untuk meraih kemandirian ekonomi.

Melalui pilar Ekonomi Inklusif Digital, PPTI memfokuskan inisiatifnya pada tiga area strategis:

1. Pemberdayaan UMKM & Ekonomi Kreatif:
Digitalisasi bukan hanya soal jualan online, tapi tentang optimalisasi operasional dan akses pasar yang lebih luas. PPTI memberikan pendampingan bagi pelaku usaha lokal untuk mengadopsi sistem pembayaran digital, manajemen inventaris modern, dan strategi pemasaran konten yang menarik minat pasar nasional maupun global.

2. Akses Keuangan Digital:
Banyak masyarakat di pelosok masih memiliki keterbatasan akses terhadap lembaga keuangan formal. PPTI mendorong integrasi layanan finansial digital (fintech) yang aman dan terpercaya, memudahkan warga dalam mendapatkan akses modal usaha, asuransi mikro, dan pengelolaan tabungan secara mandiri.

3. Penciptaan Lapangan Kerja Hijau & Digital:
Ekonomi masa depan adalah ekonomi yang berkelanjutan. Kami mendorong munculnya startup-startup lokal yang memanfaatkan teknologi untuk menyelesaikan masalah lingkungan di kawasannya, sekaligus membuka lapangan kerja baru bagi generasi muda bertalenta di daerah.

Inisiatif Ekonomi Inklusif Digital memastikan bahwa aliran kesejahteraan tidak hanya berputar di pusat kota, tetapi meresap hingga ke sendi-sendi ekonomi masyarakat di pelosok kawasan. Inilah esensi dari pembangunan yang berkeadilan di era kedaulatan digital.`,
    icon: <TrendingUp className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1556742049-13da736c7459?auto=format&fit=crop&q=80&w=800",
    stats: "Pertumbuhan Merata",
    isGraphic: false
  },
  {
    id: "ksb-layanan-publik",
    title: "Layanan Publik Terpadu Digital",
    category: "Kawasan",
    description: "Transformasi birokrasi dan kemudahan akses layanan masyarakat melalui integrasi platform digital yang transparan dan efisien di tingkat kawasan.",
    content: `Layanan Publik Terpadu Digital merupakan salah satu pilar krusial dalam inisiatif Kawasan Sejahtera Berkelanjutan (KSB). PPTI percaya bahwa teknologi harus menjadi solusi utama untuk menghilangkan hambatan birokrasi yang berbelit-belit dan menciptakan tata kelola pemerintahan yang responsif terhadap kebutuhan warga.

Melalui program ini, PPTI mendampingi pemerintah daerah dalam mengimplementasikan ekosistem layanan digital terpadu yang mencakup:

1. One-Stop Digital Service: 
Integrasi berbagai layanan administratif (seperti perizinan, kependudukan, dan bantuan sosial) ke dalam satu platform yang dapat diakses melalui perangkat mobile. Hal ini memastikan warga tidak perlu lagi berpindah-pindah instansi untuk mendapatkan layanan dasar.

2. Transparansi & Akuntabilitas Real-time: 
Sistem pelacakan permohonan yang memungkinkan warga memantau status layanan mereka secara transparan. Hal ini mengurangi potensi pungutan liar dan meningkatkan kepercayaan publik terhadap integritas birokrasi.

3. Sistem Feedback Responsif: 
Wadah bagi warga untuk memberikan masukan atau melaporkan kendala layanan secara langsung, yang kemudian diolah menjadi data evaluasi bagi pemerintah kawasan untuk perbaikan berkelanjutan.

Dengan implementasi Layanan Publik Terpadu Digital, efisiensi kerja aparatur meningkat secara signifikan, sementara kepuasan masyarakat terhadap pelayanan publik pun bertumbuh pesat. Inilah standar baru pelayanan masyarakat di era transformasi digital.`,
    icon: <Layout className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=800",
    stats: "Efisiensi Birokrasi",
    isGraphic: false
  },
  {
    id: "ksb-digital",
    title: "Kawasan Sejahtera Digital",
    category: "Kawasan",
    description: "Mewujudkan kemandirian ekonomi regional melalui integrasi ekosistem teknologi yang inklusif dan berkelanjutan di seluruh Indonesia.",
    content: `Kawasan Sejahtera Digital merupakan manifestasi nyata dari visi PPTI untuk membawa manfaat teknologi ke tingkat yang paling dekat dengan masyarakat. Inisiatif ini bukan sekadar tentang menyediakan akses internet, melainkan tentang membangun fondasi ekonomi baru yang tangguh di era digital.

Melalui program ini, PPTI mendorong setiap kawasan untuk memiliki kedaulatan digitalnya sendiri. Strategi ini diimplementasikan melalui beberapa langkah taktis:

1. Digitalisasi Rantai Pasok Lokal: 
Menghubungkan produsen lokal (petani, pengrajin, UMKM) langsung ke pasar melalui platform digital yang dikelola secara mandiri oleh komunitas kawasan. Hal ini mengurangi ketergantungan pada tengkulak dan meningkatkan margin keuntungan bagi produsen.

2. Keamanan Data Kawasan: 
Membangun kesadaran dan infrastruktur perlindungan data pribadi serta aset digital milik warga. PPTI memberikan pendampingan agar setiap transaksi dan informasi sensitif di kawasan tersebut tetap aman dari ancaman siber.

3. Literasi Digital fungsional: 
Program pelatihan yang berfokus pada penggunaan teknologi untuk produktivitas, bukan sekadar konsumsi informasi. Ini mencakup pelatihan manajemen data bisnis, pemasaran digital, hingga pemanfaatan alat kolaborasi online.

Inisiatif Kawasan Sejahtera Digital memastikan bahwa tidak ada satu pun wilayah di Indonesia yang tertinggal dalam revolusi industri 4.0. Dengan teknologi, jarak geografis tidak lagi menjadi hambatan untuk meraih kesejahteraan.`,
    icon: <Globe className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800",
    stats: "Kedaulatan Digital Lokal",
    isGraphic: false
  },
  {
    id: "ksb-pilar",
    title: "Pilar Utama Kawasan Sejahtera Berkelanjutan",
    category: "Kawasan",
    description: "Empat pilar strategis yang menjadi fondasi PPTI dalam membangun kemandirian dan kesejahteraan kawasan melalui integrasi teknologi dan keberlanjutan.",
    content: `Program Kawasan Sejahtera Berkelanjutan (KSB) yang diinisiasi oleh PPTI didasarkan pada kerangka kerja komprehensif yang terdiri dari empat pilar utama. Keempat pilar ini dirancang untuk saling mendukung guna menciptakan ekosistem yang tangguh dan adaptif terhadap perubahan zaman.

Kawasan sejahtera berkelanjutan dibangun di atas fondasi yang kokoh, dengan empat pilar utama yang saling melengkapi dan memperkuat. Layanan publik terpadu memastikan masyarakat memperoleh akses yang mudah, cepat, dan transparan terhadap berbagai kebutuhan dasar, sekaligus mendorong efisiensi birokrasi melalui digitalisasi dan koordinasi lintas instansi.

Di sisi lain, lingkungan berkelanjutan menjadi komitmen untuk menjaga keseimbangan ekosistem, mengelola sumber daya alam secara bijak, serta menghadapi tantangan perubahan iklim dengan solusi ramah lingkungan. Pilar ini menjamin kawasan tetap hijau, sehat, and layak huni bagi generasi sekarang maupun mendatang.

Selanjutnya, ekonomi inklusif menekankan pertumbuhan yang merata, membuka peluang bagi semua lapisan masyarakat, serta mendukung UMKM, ekonomi kreatif, dan lapangan kerja hijau. Dengan demikian, kesejahteraan tidak hanya dinikmati oleh segelintir pihak, tetapi dirasakan secara luas and adil.

Terakhir, kehidupan sosial menjadi roh dari kawasan sejahtera berkelanjutan. Pilar ini menumbuhkan harmoni, solidaritas, dan partisipasi aktif masyarakat melalui pendidikan, kesehatan, budaya, dan interaksi sosial yang inklusif. Kehidupan sosial yang kuat memastikan kualitas hidup masyarakat meningkat dan rasa kebersamaan tetap terjaga.

1. Layanan Publik Terpadu
Makna: Penyediaan layanan publik yang mudah diakses, terintegrasi, dan responsif terhadap kebutuhan masyarakat.
Fokus: Digitalisasi layanan, transparansi birokrasi, dan koordinasi lintas instansi.
Dampak: Masyarakat memperoleh layanan cepat, efisien, dan berkualitas tanpa birokrasi berbelit.

2. Lingkungan Berkelanjutan
Makna: Pengelolaan sumber daya alam secara bijak untuk menjaga keseimbangan ekosistem.
Fokus: Energi terbarukan, pengelolaan sampah, konservasi air, dan mitigasi perubahan iklim.
Dampak: Kawasan tetap hijau, sehat, dan layak huni bagi generasi sekarang dan mendatang.

3. Ekonomi Inklusif
Makna: Pertumbuhan ekonomi yang merata, memberi kesempatan bagi semua lapisan masyarakat.
Fokus: UMKM, ekonomi kreatif, akses keuangan, dan lapangan kerja hijau.
Dampak: Mengurangi kesenjangan sosial-ekonomi, meningkatkan kesejahteraan masyarakat secara luas.

4. Kehidupan Sosial
Makna: Kehidupan masyarakat yang harmonis, inklusif, dan berdaya.
Fokus: Pendidikan, kesehatan, budaya, partisipasi masyarakat, dan solidaritas sosial.
Dampak: Terwujud masyarakat yang sejahtera, berdaya, dan memiliki kualitas hidup tinggi.

Melalui sinergi pilar ini, PPTI berharap Kawasan Sejahtera Berkelanjutan dapat menjadi model percontohan bagi daerah lain di Indonesia dalam memaksimalkan potensi teknologi informasi demi kemajuan bersama.`,
    icon: <Target className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
    stats: "4 Pilar Strategis",
    isGraphic: false
  },
  {
    id: "ksb",
    title: "Kawasan Sejahtera Berkelanjutan",
    category: "Kawasan",
    description: "Program transformasi digital kawasan untuk mewujudkan ekosistem ekonomi yang mandiri melalui integrasi teknologi informasi.",
    content: `Inisiatif Kawasan Sejahtera Berkelanjutan (KSB) merupakan program mercusuar PPTI dalam mendukung pemerataan teknologi di seluruh penjuru Indonesia. Program ini mengintegrasikan empat pilar utama: Layanan Publik Terpadu, Lingkungan Berkelanjutan, Ekonomi Inklusif, dan Kehidupan Sosial.

Tujuan utama dari inisiatif ini adalah untuk memastikan bahwa kemajuan teknologi informasi tidak hanya dirasakan di kota besar, tetapi juga memberikan dampak nyata bagi peningkatan pendapatan masyarakat di pelosok daerah. PPTI berperan sebagai fasilitator yang menghubungkan penyedia teknologi dengan pemerintah daerah and komunitas masyarakat.

Melalui koordinasi yang intensif, KSB mendorong terciptanya tata kelola pemerintahan yang transparan, pengelolaan sumber daya yang ramah lingkungan, penguatan ekonomi rakyat melalui UMKM, serta peningkatan kualitas interaksi sosial masyarakat. Program ini adalah manifestasi dari visi PPTI untuk mewujudkan kedaulatan digital yang berkeadilan bagi seluruh rakyat Indonesia.`,
    icon: <Globe className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&q=80&w=800",
    stats: "Inisiatif Mercusuar",
    isGraphic: false
  },
  {
    id: "csd",
    title: "Community-developed Sustainability Digital",
    category: "CSR",
    description: "Pendekatan CSR di mana komunitas lokal menjadi aktor utama dalam merancang, mengimplementasikan, dan mengelola solusi digital yang mendukung keberlanjutan.",
    content: `Ini adalah pendekatan CSR di mana komunitas lokal menjadi aktor utama dalam merancang, mengimplementasikan, dan mengelola solusi digital yang mendukung keberlanjutan. Perusahaan berperan sebagai fasilitator, penyedia sumber daya, and mitra strategis, bukan sebagai pengendali penuh.
Dengan cara ini, CSR tidak hanya berupa donasi atau proyek jangka pendek, tetapi menjadi ekosistem digital berkelanjutan yang benar-benar dimiliki dan dijalankan oleh masyarakat.

A. Kontribusi dalam kegiatan Teknologi Informasi
Green Coding Practice: Menerapkan teknik pemrograman yang mengoptimalkan penggunaan sumber daya CPU and memori untuk mengurangi konsumsi listrik server.
Open Source Sustainability: Berbagi modul kode yang membantu organisasi mengukur dan mengelola dampak lingkungan dari operasi digital mereka.
Community Infrastructure: Membangun jaringan data center komunitas yang menggunakan sumber energi terbarukan di tingkat lokal.

B. Kontribusi dalam konteks program CSR (Corporate Social Responsibility).

Elemen Utama
Keterlibatan Komunitas
Komunitas menentukan kebutuhan (misalnya akses internet, aplikasi lokal, sistem data lingkungan).
Perusahaan mendukung dengan teknologi, pelatihan, dan pendanaan.
Teknologi Berkelanjutan
Menggunakan perangkat open-source, energi rendah karbon, dan sistem ramah lingkungan.
Infrastruktur digital yang bisa dipelihara oleh komunitas sendiri.
Kapasitas & Literasi Digital
Program pelatihan coding, keamanan siber, dan manajemen data.
Meningkatkan kemampuan masyarakat untuk mengelola platform digital secara mandiri.
Transparansi & Akuntabilitas
Dashboard digital untuk memantau dampak CSR (misalnya jumlah UMKM terbantu, data lingkungan).
Laporan terbuka yang bisa diakses publik.

Kesimpulan
Community-developed sustainability digital dalam CSR adalah cara untuk memastikan bahwa program tanggung jawab sosial perusahaan benar-benar berkelanjutan, inklusif, and relevan dengan kebutuhan masyarakat. Perusahaan tidak hanya memberi bantuan, tetapi membangun kapasitas digital komunitas agar mereka bisa mandiri, berdaya, dan menjaga keberlanjutan sosial-lingkungan dengan teknologi.`,
    icon: <Leaf className="text-green-600" size={32} />,
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800",
    stats: "Ekosistem Digital Mandiri",
    isGraphic: false
  },
  {
    id: "akd",
    title: "Asesmen Kompetensi Digital",
    category: "Asesmen",
    description: "Evaluasi standar kompetensi bagi praktisi TI untuk memetakan keahlian sesuai standar industri global dan SKKNI.",
    content: `Layanan Asesmen Kompetensi Digital PPTI dirancang untuk menjembatani kesenjangan antara kurikulum akademis dengan kebutuhan nyata industri teknologi informasi yang dinamis. Program ini mengacu pada standar global yang telah disesuaikan dengan kerangka kerja nasional.

    Berikut adalah lima pilar utama yang dievaluasi dalam asesmen kompetensi ini:

    1. Literasi Data dan Informasi:
    Mengukur kemampuan peserta dalam mencari, menyaring, mengevaluasi, serta mengelola data and informasi digital secara kritis and efektif di lingkungan kerja.

    2. Kolaborasi dan Komunikasi:
    Menilai kecakapan dalam berinteraksi, berbagi, dan berkolaborasi melalui teknologi digital, termasuk penguasaan etika digital (netiket) dalam lingkungan profesional.

    3. Pembuatan Konten Digital:
    Mengevaluasi kemampuan menciptakan dan mengedit konten baru dalam berbagai format, mengintegrasikan informasi, serta pemahaman mendalam mengenai hak cipta dan lisensi digital.

    4. Keamanan (Security):
    Aspek krusial yang menguji pemahaman dalam melindungi perangkat keras, konten digital, perlindungan data pribadi, serta menjaga kesehatan fisik dan psikologis di ruang siber.

    5. Penyelesaian Masalah (Problem Solving):
    Menguji ketajaman dalam mengidentifikasi kebutuhan dan masalah teknis, serta kemampuan menggunakan sarana digital secara kreatif untuk memberikan solusi yang efisien.

    Manfaat utama bagi anggota:
    - Pemetaan keahlian (skill mapping) yang akurat untuk jenjang karir.
    - Pengakuan profesionalitas dari organisasi keprofesian nasional.
    - Akses ke program sertifikasi lanjutan yang relevan dengan hasil asesmen.

    Program ini merupakan bagian dari komitmen PPTI dalam mencetak SDM unggul yang siap menghadapi tantangan ekonomi digital di masa depan.`,
    icon: <Award className="text-blue-600" size={32} />,
    image: akdLogoUri,
    stats: "5 Pilar Utama",
    isGraphic: true
  },
  {
    id: "dmm",
    title: "Manajemen Data (DMM)",
    category: "Data",
    description: "Penerapan model Data Management Maturity (DMM) untuk mengukur kapabilitas tata kelola data organisasi.",
    content: `Data Management Maturity (DMM) Assessment adalah layanan evaluasi komprehensif yang ditawarkan PPTI bagi organisasi yang ingin bertransformasi menjadi entitas berbasis data (data-driven).

    Menggunakan kerangka kerja internasional yang disesuaikan dengan konteks Indonesia, DMM mencakup 6 area kritis: Tata Kelola Data, Kualitas Data, Operasi Data, Strategi Platform, Arsitektur Data, dan Analitik.

    Mengapa DMM Penting?
    1. Menemukan kesenjangan (gap) dalam pengelolaan informasi organisasi.
    2. Memberikan roadmap perbaikan yang terukur untuk efisiensi biaya.
    3. Meningkatkan kepercayaan stakeholder terhadap akurasi laporan bisnis.
    4. Memastikan kepatuhan terhadap regulasi perlindungan data pribadi.

    PPTI menyediakan tim asesor profesional yang membantu organisasi tidak hanya menilai tingkat kematangan saat ini, tetapi juga mendampingi dalam proses peningkatan (improvement) menuju standar global melalui model Capability as a Service (CaaS).`,
    icon: <Database className="text-blue-600" size={32} />,
    image: dmmImageUri,
    stats: "Metodologi DMM-CaaS",
    isGraphic: true
  },
  {
    id: "about-digital-csr",
    title: "Tentang CSR Digital",
    category: "CSR",
    description: "Evolusi tanggung jawab sosial perusahaan melalui integrasi ekosistem digital dan pemanfaatan data untuk dampak sosial yang lebih luas.",
    content: `CSR Digital bukan sekadar memindahkan bantuan ke ranah online. Ini adalah transformasi filosofis tentang bagaimana teknologi dapat mempercepat penyelesaian masalah sosial.

PPTI memandang CSR Digital sebagai instrumen kunci untuk meningkatkan inklusivitas. Melalui digitalisasi, perusahaan dapat menjangkau penerima manfaat di pelosok Nusantara dengan biaya operasional yang jauh lebih efisien.

Fokus utama CSR Digital PPTI meliputi:
1. Akselerasi Infrastruktur: Mendukung pembangunan node-node internet di daerah 3T.
2. Literasi Massal: Kampanye keamanan data dan penggunaan internet sehat bagi masyarakat awam.
3. Ekosistem Inovasi: Menciptakan wadah bagi startup lokal untuk menyelesaikan tantangan di komunitasnya sendiri.`,
    icon: <BookOpen className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800",
    stats: "Wawasan Keberlanjutan",
    isGraphic: false
  },
  {
    id: "csr-app",
    title: "Aplikasi CSR",
    category: "CSR",
    description: "Platform manajemen dan monitoring program CSR untuk transparansi dan akuntabilitas pelaporan dampak secara real-time.",
    content: `Transparansi adalah tantangan terbesar dalam program CSR tradisional. Aplikasi CSR berbasis cloud hadir untuk memberikan visibilitas penuh bagi semua pihak yang terlibat.

Fitur utama Aplikasi CSR yang direkomendasikan PPTI:
1. Real-time Dashboard: Memantau penyaluran dana dan progres kegiatan di lapangan secara instan.
2. Geo-tagging: Memastikan lokasi penerima manfaat tervalidasi secara geografis.
3. Impact Calculator: Menghitung SROI (Social Return on Investment) secara otomatis berdasarkan data yang masuk.

Dengan platform digital, laporan tahunan keberlanjutan perusahaan tidak lagi sekadar angka, tapi narasi data yang dapat dipertanggungjawabkan secara publik.`,
    icon: <Layout className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
    stats: "Solusi Teknologi",
    isGraphic: false
  },
  {
    id: "stakeholder-engagement",
    title: "Stakeholder Engagement Digital",
    category: "CSR",
    description: "Membangun ekosistem komunikasi dua arah yang harmonis antara korporasi, pemerintah, dan komunitas lokal melalui platform digital terpadu.",
    content: `Keberhasilan program Tanggung Jawab Sosial Perusahaan (CSR) di era modern sangat bergantung pada kualitas keterlibatan pemangku kepentingan (stakeholder engagement). PPTI mengadvokasi penggunaan platform digital sebagai jembatan yang mempertemukan aspirasi masyarakat, target pembangunan pemerintah, dan sumber daya korporasi.

Melalui pendekatan digital, stakeholder engagement tidak lagi bersifat top-down, melainkan sebuah dialog yang inklusif dan berkelanjutan. Berikut adalah tiga fitur kunci yang dikembangkan dalam platform engagement PPTI:

1. Community Portals (Portal Komunitas):
Sebuah wadah interaktif bagi warga lokal untuk menyuarakan aspirasi, kebutuhan, dan keluhan mereka secara real-time. Fitur ini memungkinkan perusahaan untuk mendengarkan langsung apa yang dibutuhkan oleh masyarakat di sekitar wilayah operasionalnya, sehingga program CSR yang dirancang menjadi lebih relevan dan tepat sasaran. Portal ini juga berfungsi sebagai pusat transparansi progres program pembangunan yang sedang berjalan.

2. Government Connect (Integrasi Pemerintah):
Menyediakan modul pelaporan dan koordinasi yang terintegrasi dengan target pembangunan pemerintah daerah (SDGs lokal). Fitur ini memastikan bahwa setiap kontribusi korporasi selaras dengan prioritas pembangunan pemerintah, menghindari duplikasi program, dan memaksimalkan dampak kolektif bagi kawasan tersebut.

3. Employee Volunteering System (Sistem Relawan Karyawan):
Platform ini memungkinkan karyawan perusahaan untuk terlibat langsung sebagai mentor teknologi atau tenaga ahli sukarela bagi komunitas. Melalui sistem matching digital, keahlian spesifik karyawan (seperti manajemen TI, pemrograman, atau keamanan data) dapat disalurkan secara efektif ke sekolah-sekolah lokal atau UMKM yang membutuhkan pendampingan teknis.

Dengan mengintegrasikan ketiga fitur ini, perusahaan tidak hanya sekadar memberikan bantuan, tetapi juga membangun rasa kepemilikan (sense of ownership) dari masyarakat terhadap teknologi dan inisiatif yang diimplementasikan. Stakeholder Engagement Digital menciptakan harmoni sosial yang menjadi fondasi utama bagi keberlanjutan bisnis dan kesejahteraan kawasan.`,
    icon: <Users className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1521791136064-7986c2959210?auto=format&fit=crop&q=80&w=800",
    stats: "Kolaborasi Multi-Pihak",
    isGraphic: false
  },
  {
    id: "csr-sdgs",
    title: "Perencanaan program CSR berbasis SDGs",
    category: "CSR",
    description: "Menyusun strategi tanggung jawab sosial yang selaras dengan 17 Tujuan Pembangunan Berkelanjutan (SDGs) global.",
    content: `Agar program CSR memiliki dampak jangka panjang, perencanaan harus mengacu pada kerangka kerja global Sustainable Development Goals (SDGs).

PPTI membantu merancang program yang fokus pada:
- SDGs 4 (Kualitas Pendidikan): Melalui beasiswa pelatihan coding dan literasi digital.
- SDGs 8 (Pekerjaan Layak & Pertumbuhan Ekonomi): Melalui digitalisasi UMKM lokal.
- SDGs 9 (Industri, Inovasi & Infrastruktur): Melalui pengembangan aplikasi komunitas yang inovatif.

Perencanaan berbasis SDGs memastikan bahwa kontribusi perusahaan diakui di tingkat internasional dan memberikan dampak nyata yang terukur bagi peradaban.`,
    icon: <Target className="text-blue-600" size={32} />,
    image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800",
    stats: "Target Global",
    isGraphic: false
  }
];