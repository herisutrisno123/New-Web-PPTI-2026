
import { Member } from '../types';

// Helper untuk menghasilkan gambar kartu anggota dinamis berbasis SVG
export const getMembershipCard = (name: string, id: string, title: string) => {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="400" height="250" viewBox="0 0 400 250">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#0038a8;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#001d54;stop-opacity:1" />
        </linearGradient>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="white" stroke-width="0.5" stroke-opacity="0.1"/>
        </pattern>
      </defs>
      <rect width="400" height="250" rx="20" fill="url(#grad)" />
      <rect width="400" height="250" rx="20" fill="url(#grid)" />
      
      <circle cx="50" cy="50" r="25" fill="white" fill-opacity="0.2" />
      <text x="38" y="58" font-family="Arial" font-weight="900" font-size="24" fill="white">P</text>
      
      <text x="90" y="45" font-family="Arial" font-weight="900" font-size="14" fill="white" letter-spacing="2">PPTI INDONESIA</text>
      <text x="90" y="62" font-family="Arial" font-size="8" fill="white" fill-opacity="0.6" letter-spacing="1">PROFESSIONAL MEMBERSHIP CARD</text>
      
      <text x="40" y="140" font-family="Arial" font-weight="900" font-size="20" fill="white">${name.toUpperCase() || 'NAMA ANGGOTA'}</text>
      <text x="40" y="165" font-family="Arial" font-size="12" fill="white" fill-opacity="0.8">${title || 'Jabatan Profesional'}</text>
      
      <line x1="40" y1="185" x2="360" y2="185" stroke="white" stroke-opacity="0.2" stroke-width="1" />
      
      <text x="40" y="215" font-family="Courier New" font-weight="bold" font-size="14" fill="#60a5fa">${id || 'PPTI-XXXX-XXXX'}</text>
      <text x="360" y="215" text-anchor="end" font-family="Arial" font-weight="900" font-size="10" fill="#4ade80">VERIFIED PROFESSIONAL</text>
    </svg>
  `;
  return `data:image/svg+xml;base64,${btoa(svg)}`;
};

export const initialMembers: Member[] = [
  {
    id: 'PPTI-2018-0001',
    name: 'Budi Raharjo',
    title: 'Senior Software Architect',
    avatar: getMembershipCard('Budi Raharjo', 'PPTI-2018-0001', 'Senior Software Architect'),
    location: 'Jakarta, Indonesia',
    bio: 'Berpengalaman lebih dari 15 tahun di industri perbankan dan fintech. Spesialis dalam arsitektur microservices dan keamanan sistem skala besar.',
    skills: ['Golang', 'Kubernetes', 'Cybersecurity', 'System Design', 'Cloud Native'],
    experience: [
      { year: '2020 - Present', role: 'CTO', company: 'Fintech Maju Jaya' },
      { year: '2015 - 2020', role: 'Lead Architect', company: 'Bank Central Digital' }
    ],
    socials: { linkedin: '#', github: '#' }
  },
  {
    id: 'PPTI-2019-0422',
    name: 'Siska Amelia',
    title: 'Cloud Solutions Engineer',
    avatar: getMembershipCard('Siska Amelia', 'PPTI-2019-0422', 'Cloud Solutions Engineer'),
    location: 'Bandung, Indonesia',
    bio: 'Ahli dalam optimasi infrastruktur cloud (AWS/GCP) dengan fokus pada efisiensi biaya dan skalabilitas otomatis.',
    skills: ['Terraform', 'AWS', 'Python', 'DevOps', 'Docker'],
    experience: [
      { year: '2021 - Present', role: 'Senior Cloud Engineer', company: 'Global Tech Solution' },
      { year: '2018 - 2021', role: 'DevOps Engineer', company: 'StartUp Indo' }
    ],
    socials: { linkedin: '#', twitter: '#' }
  },
  {
    id: 'PPTI-2022-1105',
    name: 'Adi Wijaya',
    title: 'AI & Data Science Specialist',
    avatar: getMembershipCard('Adi Wijaya', 'PPTI-2022-1105', 'AI Specialist'),
    location: 'Yogyakarta, Indonesia',
    bio: 'Peneliti AI dengan fokus pada Natural Language Processing. Aktif berkontribusi dalam komunitas open-source Indonesia.',
    skills: ['PyTorch', 'TensorFlow', 'LLMs', 'SQL'],
    experience: [
      { year: '2022 - Present', role: 'AI Researcher', company: 'AI Lab Nusantara' },
      { year: '2019 - 2022', role: 'Data Scientist', company: 'E-Commerce Giant' }
    ],
    socials: { github: '#', linkedin: '#' }
  },
  {
    id: 'PPTI-2021-0887',
    name: 'Maya Putri',
    title: 'Cybersecurity Analyst',
    avatar: getMembershipCard('Maya Putri', 'PPTI-2021-0887', 'Cybersecurity Analyst'),
    location: 'Surabaya, Indonesia',
    bio: 'Fokus pada penetration testing dan audit keamanan sistem informasi pemerintahan.',
    skills: ['Cybersecurity', 'Python', 'Linux', 'Network Security', 'SOC', 'Cryptography'],
    experience: [
      { year: '2021 - Present', role: 'Security Consultant', company: 'CyberGuard ID' },
      { year: '2019 - 2021', role: 'Junior Analyst', company: 'Tech Defense' }
    ],
    socials: { linkedin: '#' }
  }
];
