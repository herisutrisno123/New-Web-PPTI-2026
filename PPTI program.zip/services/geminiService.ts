import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  async generateChatResponse(message: string, history: { role: string; parts: { text: string }[] }[]) {
    try {
      // Membuat instance baru tepat sebelum pemanggilan API sesuai pedoman
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Memastikan riwayat chat valid (dimulai dari user jika ada riwayat)
      const validHistory = history.length > 0 && history[0].role === 'model' ? history.slice(1) : history;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: validHistory.concat([{ role: 'user', parts: [{ text: message }] }]),
        config: {
          systemInstruction: `Anda adalah asisten AI resmi untuk PPTI (Perkumpulan Profesional Teknologi Informasi). 
          PPTI didirikan pada 1 Juni 2018 di Jakarta sebagai organisasi profesional, mandiri, dan non-profit.

          Visi: "Menjadi organisasi yang terpercaya, profesional, dan berdaya saing nasional dan internasional sesuai profesi."
          
          Gunakan Bahasa Indonesia yang formal, sopan, dan sangat membantu. Bantu pengunjung memahami:
          1. Manfaat keanggotaan PPTI (Umum & Perusahaan).
          2. Program Kawasan Sejahtera Berkelanjutan (KSB).
          3. Standar kompetensi digital dan asesmen DMM-CaaS.
          4. Informasi umum seputar tren teknologi di Indonesia.`,
          temperature: 0.7,
        },
      });

      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Mohon maaf, sistem asisten AI sedang dalam pemeliharaan singkat. Silakan hubungi kami melalui formulir kontak untuk respon cepat.";
    }
  }
}

export const gemini = new GeminiService();