
import React, { useEffect, useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import LatestInfo from './components/LatestInfo';
import VisitorStats from './components/VisitorStats';
import MembershipBenefits from './components/MembershipBenefits';
import MemberList from './components/MemberList';
import MemberDetail from './components/MemberDetail';
import ArticleDetail from './components/ArticleDetail';
import MembershipForm from './components/MembershipForm';
import ConsultationPortal from './components/ConsultationPortal';
import AllNews from './components/AllNews';
import AIChat from './components/AIChat';
import ContactModal from './components/ContactModal';
import PrivacyPolicy from './components/PrivacyPolicy';
import Footer from './components/Footer';
import AdminPanel from './components/AdminPanel';
import { Member } from './types';
import { Article, articles } from './data/articles';
import { initialMembers } from './data/members';
import { ArrowLeft } from 'lucide-react';

type ViewState = 'home' | 'about' | 'members' | 'detail' | 'article-detail' | 'registration' | 'consultation' | 'all-news' | 'admin' | 'privacy-policy';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ViewState>('home');
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [registrationType, setRegistrationType] = useState<'umum' | 'perusahaan'>('umum');
  const [isContactOpen, setIsContactOpen] = useState(false);
  
  // State manajemen anggota
  const [members, setMembers] = useState<Member[]>(initialMembers);

  // State manajemen keahlian (diambil dari data anggota yang ada sebagai inisialisasi)
  const [allSkills, setAllSkills] = useState<string[]>(() => {
    const uniqueSkills = new Set<string>();
    initialMembers.forEach(m => m.skills.forEach(s => uniqueSkills.add(s)));
    return Array.from(uniqueSkills).sort();
  });

  useEffect(() => {
    window.scrollTo(0, 0);

    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, [activeView, selectedMember, selectedArticle]);

  const handleGlobalNav = (href: string) => {
    if (href === '#kontak') {
      setIsContactOpen(true);
      return;
    }
    
    if (href === '#login') {
      setActiveView('admin');
      return;
    }

    if (href === '#about') {
      setActiveView('about');
      return;
    }

    if (href === '#members') {
      setActiveView('members');
      return;
    }

    if (href === '#privacy-policy') {
      setActiveView('privacy-policy');
      return;
    }

    if (href === '#hero' || href === '#home') {
      setActiveView('home');
      return;
    }

    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleMemberClick = (member: Member) => {
    setSelectedMember(member);
    setActiveView('detail');
  };

  const handleArticleClick = (article: Article) => {
    setSelectedArticle(article);
    setActiveView('article-detail');
  };

  if (activeView === 'admin') {
    return (
      <AdminPanel 
        onLogout={() => setActiveView('home')} 
        members={members}
        setMembers={setMembers}
        allSkills={allSkills}
        setAllSkills={setAllSkills}
      />
    );
  }

  const renderContent = () => {
    switch (activeView) {
      case 'about':
        return (
          <div className="pt-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
              <button onClick={() => setActiveView('home')} className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-4 transition-colors group">
                <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> Kembali ke Beranda
              </button>
            </div>
            <About />
          </div>
        );
      case 'members':
        return (
          <div className="pt-20">
             <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
              <button onClick={() => setActiveView('home')} className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-4 transition-colors group">
                <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> Kembali ke Beranda
              </button>
            </div>
            <MemberList members={members} onMemberClick={handleMemberClick} />
          </div>
        );
      case 'detail':
        return selectedMember ? (
          <MemberDetail 
            member={selectedMember} 
            onBack={() => setActiveView('members')} 
            onContactClick={() => setIsContactOpen(true)}
          />
        ) : null;
      case 'article-detail':
        return selectedArticle ? (
          <ArticleDetail 
            article={selectedArticle} 
            relatedArticles={articles.filter(a => a.id !== selectedArticle.id && a.category === selectedArticle.category)} 
            onBack={() => setActiveView('all-news')} 
            onArticleClick={handleArticleClick}
            onContactClick={() => setIsContactOpen(true)}
          />
        ) : null;
      case 'registration':
        return <MembershipForm onBack={() => setActiveView('home')} initialType={registrationType} />;
      case 'consultation':
        return <ConsultationPortal onBack={() => setActiveView('home')} />;
      case 'all-news':
        return <AllNews onArticleClick={handleArticleClick} onBack={() => setActiveView('home')} />;
      case 'privacy-policy':
        return <PrivacyPolicy onBack={() => setActiveView('home')} />;
      default:
        return (
          <>
            <Hero 
              onAboutClick={() => setActiveView('about')} 
              onRegisterClick={(type) => { setRegistrationType(type); setActiveView('registration'); }} 
            />
            <LatestInfo 
              onArticleClick={handleArticleClick} 
              onConsultationClick={() => setActiveView('consultation')}
              onViewAllClick={() => setActiveView('all-news')}
            />
            <MembershipBenefits onRegister={(type) => { setRegistrationType(type); setActiveView('registration'); }} />
            <VisitorStats />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans">
      <Navbar onNavClick={handleGlobalNav} />
      
      <main>
        {renderContent()}
      </main>

      <Footer onContactClick={() => setIsContactOpen(true)} onNavClick={handleGlobalNav} />
      <AIChat />
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
    </div>
  );
};

export default App;
