import React from 'react';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface MemberBenefit {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface Member {
  id: string;
  name: string;
  title: string;
  avatar: string;
  bio: string;
  location: string;
  skills: string[];
  experience: {
    year: string;
    role: string;
    company: string;
  }[];
  socials: {
    linkedin?: string;
    github?: string;
    twitter?: string;
  };
}