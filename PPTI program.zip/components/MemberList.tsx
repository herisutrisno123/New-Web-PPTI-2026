
import React, { useState, useMemo } from 'react';
import { Member } from '../types';
import { ExternalLink, MapPin, Filter, CheckCircle2, XCircle, Award, CreditCard } from 'lucide-react';

interface MemberListProps {
  members: Member[];
  onMemberClick: (member: Member) => void;
}

const MemberList: React.FC<MemberListProps> = ({ members, onMemberClick }) => {
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);

  const skillStats = useMemo(() => {
    const statsMap = new Map<string, number>();
    members.forEach(member => {
      member.skills.forEach(skill => {
        statsMap.set(skill, (statsMap.get(skill) || 0) + 1);
      });
    });
    
    return Array.from(statsMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [members]);

  const filteredMembers = useMemo(() => {
    if (selectedSkills.length === 0) return members;
    return members.filter(member => 
      member.skills.some(skill => selectedSkills.includes(skill))
    );
  }, [selectedSkills, members]);

  const toggleSkill = (skill: string) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill) 
        : [...prev, skill]
    );
  };

  const clearFilters = () => setSelectedSkills([]);

  return (
    <section id="members" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <pattern id="dotPattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill="#0038a8" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#dotPattern)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 reveal reveal-up">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest mb-4 border border-blue-100">
            <Award size={14} /> Profesional Terverifikasi
          </div>
          <h2 className="text-4xl font-black text-slate-900 sm:text-5xl tracking-tight">Direktori Anggota</h2>
          <p className="mt-4 text-slate-500 max-w-2xl mx-auto text-lg font-medium leading-relaxed">
            Identitas resmi para pakar TI Indonesia yang telah terdaftar dalam ekosistem PPTI.
          </p>
        </div>

        <div className="mb-12 bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 reveal reveal-up delay-100">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2.5 rounded-xl text-white shadow-lg shadow-blue-200">
                <Filter size={20} />
              </div>
              <span className="font-black text-slate-900 text-sm uppercase tracking-widest">Filter Spesialisasi</span>
            </div>
            
            {selectedSkills.length > 0 && (
              <button 
                onClick={clearFilters}
                className="flex items-center gap-2 text-xs font-bold text-red-500 hover:text-red-600 transition-colors bg-red-50 px-5 py-2.5 rounded-2xl"
              >
                <XCircle size={16} /> Hapus Filter ({selectedSkills.length})
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-2.5">
            {skillStats.map((skill) => {
              const isActive = selectedSkills.includes(skill.name);
              return (
                <button
                  key={skill.name}
                  onClick={() => toggleSkill(skill.name)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-xs font-bold transition-all duration-300 border-2 ${
                    isActive
                      ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-200'
                      : 'bg-white border-transparent text-slate-600 hover:border-blue-200 hover:text-blue-600 shadow-sm'
                  }`}
                >
                  {skill.name}
                  <span className={`px-2 py-0.5 rounded-lg text-[9px] ${
                    isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-400'
                  }`}>
                    {skill.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {filteredMembers.length > 0 ? (
            filteredMembers.map((member, idx) => (
              <div 
                key={member.id}
                onClick={() => onMemberClick(member)}
                className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 hover:shadow-2xl hover:-translate-y-2 transition-all cursor-pointer group relative overflow-hidden reveal reveal-up flex flex-col lg:flex-row gap-6 items-center"
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                <div className="w-full lg:w-[280px] shrink-0 relative perspective-1000">
                  <div className="relative transform transition-transform duration-700 group-hover:rotate-y-12">
                    <img 
                      src={member.avatar} 
                      alt={`Kartu Anggota ${member.name}`} 
                      className="w-full h-auto rounded-2xl shadow-xl border border-white/20"
                    />
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none"></div>
                  </div>
                  <div className="absolute -bottom-3 -right-3 bg-white p-2 rounded-xl shadow-lg border border-slate-50 opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100">
                    <CreditCard className="text-blue-600" size={20} />
                  </div>
                </div>
                
                <div className="flex-1 space-y-4 text-center lg:text-left">
                  <div>
                    <h4 className="text-2xl font-black text-slate-900 group-hover:text-blue-600 transition-colors leading-tight mb-1">{member.name}</h4>
                    <p className="text-sm text-blue-600 font-black uppercase tracking-wider">{member.title}</p>
                    <p className="text-[10px] font-mono font-bold text-slate-400 mt-1">{member.id}</p>
                  </div>
                  
                  <div className="flex flex-wrap justify-center lg:justify-start gap-1.5">
                    {member.skills.slice(0, 3).map(skill => (
                      <span 
                        key={skill} 
                        className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-wider transition-all ${
                          selectedSkills.includes(skill) 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-slate-50 text-slate-400'
                        }`}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                  
                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 font-medium">
                    {member.bio}
                  </p>

                  <div className="flex items-center justify-center lg:justify-start gap-2 pt-2">
                    <MapPin size={12} className="text-slate-300" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{member.location}</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-24 text-center bg-slate-50 rounded-[4rem] border-2 border-dashed border-slate-200">
              <div className="bg-white w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 text-slate-300 shadow-sm">
                <Filter size={40} strokeWidth={1.5} />
              </div>
              <h4 className="text-2xl font-black text-slate-900 mb-2">Anggota Tidak Ditemukan</h4>
              <p className="text-slate-500 font-medium max-w-sm mx-auto">Coba bersihkan filter spesialisasi untuk melihat semua anggota unggulan kami.</p>
              <button 
                onClick={clearFilters}
                className="mt-8 bg-blue-600 text-white px-10 py-4 rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all active:scale-95"
              >
                Lihat Semua Anggota
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default MemberList;
