import React, { useEffect } from 'react';
import { ArrowLeft, ShieldCheck, Lock, Eye, Database, FileText } from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white pb-20 animate-in fade-in duration-500 pt-24">
      <div className="max-w-4xl mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-10 transition-colors group"
        >
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          Kembali ke Beranda
        </button>

        <div className="space-y-12">
          <header className="border-b border-slate-100 pb-10">
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest mb-4">
              <ShieldCheck size={16} /> Dokumen Resmi
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight">Kebijakan Privasi</h1>
            <p className="text-slate-500 mt-4 text-lg">Terakhir diperbarui: 24 Mei 2024</p>
          </header>

          <section className="prose prose-slate max-w-none space-y-8">
            <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100">
              <p className="text-slate-700 leading-relaxed font-medium italic">
                "PPTI berkomitmen untuk melindungi privasi Anda. Kebijakan ini menjelaskan bagaimana kami mengumpulkan, menggunakan, dan melindungi informasi pribadi Anda sebagai anggota atau pengunjung situs kami."
              </p>
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                <Database className="text-blue-600" size={24} /> 1. Informasi yang Kami Kumpulkan
              </h2>
              <p className="text-slate-600 leading-relaxed">
                Kami mengumpulkan informasi yang Anda berikan langsung kepada kami saat mendaftar menjadi anggota, mengisi formulir kontak, atau menggunakan portal konsultasi. Informasi ini meliputi:
              </p>
              <ul className="grid md:grid-cols-2 gap-4 list-none pl-0">
                {[
                  "Nama Lengkap & Gelar",
                  "Alamat Email & Nomor WhatsApp",
                  "Data Institusi/Perusahaan",
                  "Keahlian & Pengalaman Profesional",
                  "Nomor NPWP (Khusus Anggota Perusahaan)"
                ].map((item, i) => (
                  <li key={i} className="bg-white border border-slate-100 p-4 rounded-2xl flex items-center gap-3 shadow-sm">
                    <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                    <span className="text-sm font-bold text-slate-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                <Eye className="text-blue-600" size={24} /> 2. Penggunaan Informasi
              </h2>
              <p className="text-slate-600 leading-relaxed">
                Informasi yang kami kumpulkan digunakan semata-mata untuk kepentingan organisasi dan pelayanan anggota, antara lain:
              </p>
              <div className="space-y-4">
                <div className="flex gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-colors">
                  <div className="bg-blue-100 text-blue-600 p-3 rounded-xl h-fit"><FileText size={20}/></div>
                  <div>
                    <h4 className="font-bold text-slate-900">Administrasi Keanggotaan</h4>
                    <p className="text-sm text-slate-500">Verifikasi data profil profesional dan penerbitan sertifikat resmi PPTI.</p>
                  </div>
                </div>
                <div className="flex gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-colors">
                  <div className="bg-blue-100 text-blue-600 p-3 rounded-xl h-fit"><Lock size={20}/></div>
                  <div>
                    <h4 className="font-bold text-slate-900">Keamanan Akses</h4>
                    <p className="text-sm text-slate-500">Menyediakan akses aman ke portal anggota dan sistem konsultasi teknis.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                <Lock className="text-blue-600" size={24} /> 3. Perlindungan Data
              </h2>
              <p className="text-slate-600 leading-relaxed">
                PPTI menerapkan standar keamanan enkripsi data untuk mencegah akses yang tidak sah. Kami tidak akan pernah menjual, menyewakan, atau membagikan data pribadi Anda kepada pihak ketiga untuk tujuan komersial tanpa persetujuan eksplisit dari Anda.
              </p>
            </div>

            <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white flex flex-col md:flex-row items-center justify-between gap-8">
              <div>
                <h3 className="text-xl font-bold mb-2">Pertanyaan seputar Privasi?</h3>
                <p className="text-slate-400 text-sm">Hubungi petugas perlindungan data kami untuk klarifikasi lebih lanjut.</p>
              </div>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-2xl font-bold transition-all whitespace-nowrap">
                Hubungi DPO PPTI
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;