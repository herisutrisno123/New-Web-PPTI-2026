
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  Building2, 
  FileText, 
  CheckCircle2, 
  ChevronRight,
  Loader2,
  Globe,
  ShieldCheck,
  X
} from 'lucide-react';

interface MembershipFormProps {
  onBack: () => void;
  initialType?: 'umum' | 'perusahaan';
}

const MembershipForm: React.FC<MembershipFormProps> = ({ onBack, initialType = 'umum' }) => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [membershipType, setMembershipType] = useState(initialType);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    province: '',
    city: '',
    organization: '',
    profession: '',
    jobTitle: '',
    specialization: '',
    linkedinUrl: '',
    reason: '',
    npwp: ''
  });

  const nextStep = () => setStep(prev => prev + 1);
  const prevStep = () => setStep(prev => prev - 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulasi proses pendaftaran
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 animate-in fade-in zoom-in-95 duration-500">
        <div className="max-w-md w-full text-center bg-white p-12 rounded-[3rem] shadow-2xl border border-slate-100">
          <div className="bg-green-100 text-green-600 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={48} />
          </div>
          <h3 className="text-3xl font-black text-slate-900 mb-4">Pendaftaran Terkirim!</h3>
          <p className="text-slate-500 mb-10 leading-relaxed">
            Terima kasih telah mendaftar sebagai anggota PPTI. Tim kami akan melakukan verifikasi data Anda dalam 2x24 jam kerja.
          </p>
          <button 
            onClick={onBack}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all"
          >
            Kembali ke Beranda
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 animate-in slide-in-from-bottom-4 duration-500">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-8 transition-colors group"
      >
        <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        Batal dan Kembali
      </button>

      <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100 flex flex-col md:flex-row">
        {/* Sidebar Info */}
        <div className="md:w-1/3 bg-blue-600 p-10 text-white flex flex-col justify-between">
          <div>
            <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center mb-8">
              <FileText size={32} />
            </div>
            <h2 className="text-3xl font-black mb-4 leading-tight">Formulir Keanggotaan</h2>
            <p className="text-blue-100 text-sm leading-relaxed mb-8">
              Lengkapi data Anda untuk bergabung dalam ekosistem profesional teknologi informasi terbesar di Indonesia.
            </p>
          </div>

          <div className="space-y-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold transition-all ${step === s ? 'bg-white text-blue-600 border-white' : 'border-white/30 text-white/50'}`}>
                  {s}
                </div>
                <span className={`text-xs font-bold uppercase tracking-widest ${step === s ? 'text-white' : 'text-white/40'}`}>
                  {s === 1 ? 'Data Diri' : s === 2 ? 'Profesional' : 'Konfirmasi'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="md:w-2/3 p-10 lg:p-14">
          <form onSubmit={handleSubmit} className="space-y-8">
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    type="button"
                    onClick={() => setMembershipType('umum')}
                    className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${membershipType === 'umum' ? 'border-blue-600 bg-blue-50' : 'border-slate-100 hover:border-blue-200'}`}
                  >
                    <User size={24} className={membershipType === 'umum' ? 'text-blue-600' : 'text-slate-400'} />
                    <span className="text-sm font-bold">Perorangan</span>
                  </button>
                  <button 
                    type="button"
                    onClick={() => setMembershipType('perusahaan')}
                    className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${membershipType === 'perusahaan' ? 'border-blue-600 bg-blue-50' : 'border-slate-100 hover:border-blue-200'}`}
                  >
                    <Building2 size={24} className={membershipType === 'perusahaan' ? 'text-blue-600' : 'text-slate-400'} />
                    <span className="text-sm font-bold">Perusahaan</span>
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required
                      type="text" 
                      placeholder={membershipType === 'umum' ? "Nama Lengkap" : "Nama Perusahaan"}
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                      value={formData.fullName}
                      onChange={e => setFormData({...formData, fullName: e.target.value})}
                    />
                  </div>

                  {membershipType === 'perusahaan' && (
                    <div className="relative animate-in slide-in-from-top-2 duration-300">
                      <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                      <input 
                        required
                        type="text" 
                        placeholder="Nomor NPWP Perusahaan (00.000.000.0-000.000)"
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all font-mono"
                        value={formData.npwp}
                        onChange={e => setFormData({...formData, npwp: e.target.value})}
                      />
                      <p className="text-[10px] text-slate-400 mt-1 ml-4 italic">* Wajib bagi anggota kategori Perusahaan untuk verifikasi pajak.</p>
                    </div>
                  )}

                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required
                      type="email" 
                      placeholder="Alamat Email Aktif"
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required
                      type="tel" 
                      placeholder="Nomor WhatsApp"
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={nextStep}
                  className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all"
                >
                  Langkah Selanjutnya <ChevronRight size={18} />
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                <div className="space-y-4">
                  <div className="relative">
                    <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required
                      type="text" 
                      placeholder={membershipType === 'umum' ? "Profesi / Pekerjaan Saat Ini" : "Bidang Industri Perusahaan"}
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                      value={formData.profession}
                      onChange={e => setFormData({...formData, profession: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="relative">
                      <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                      <input 
                        required
                        type="text" 
                        placeholder="Provinsi"
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                        value={formData.province}
                        onChange={e => setFormData({...formData, province: e.target.value})}
                      />
                    </div>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                      <input 
                        required
                        type="text" 
                        placeholder="Kota / Kabupaten"
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all"
                        value={formData.city}
                        onChange={e => setFormData({...formData, city: e.target.value})}
                      />
                    </div>
                  </div>

                  <textarea 
                    rows={4}
                    placeholder="Apa motivasi Anda bergabung dengan PPTI?"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all resize-none"
                    value={formData.reason}
                    onChange={e => setFormData({...formData, reason: e.target.value})}
                  ></textarea>
                </div>
                <div className="flex flex-col gap-3">
                  <div className="flex gap-4">
                    <button 
                      type="button"
                      onClick={prevStep}
                      className="flex-1 border-2 border-slate-100 text-slate-500 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-all"
                    >
                      Kembali
                    </button>
                    <button 
                      type="button"
                      onClick={nextStep}
                      className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all"
                    >
                      Hampir Selesai <ChevronRight size={18} />
                    </button>
                  </div>
                  <button 
                    type="button"
                    onClick={onBack}
                    className="w-full py-3 text-slate-400 hover:text-red-500 transition-colors text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <X size={14} /> Batalkan Pendaftaran
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <h4 className="font-bold text-slate-900 mb-4">Ringkasan Pendaftaran</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Tipe Anggota:</span>
                      <span className="font-bold text-blue-600 uppercase">{membershipType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{membershipType === 'umum' ? 'Nama:' : 'Nama Perusahaan:'}</span>
                      <span className="font-bold text-slate-900">{formData.fullName}</span>
                    </div>
                    {membershipType === 'perusahaan' && (
                      <div className="flex justify-between items-center py-2 bg-blue-100/30 px-3 rounded-lg border border-blue-100/50">
                        <span className="text-blue-700 font-medium">NPWP Perusahaan:</span>
                        <span className="font-mono font-bold text-slate-900">{formData.npwp}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-slate-500">{membershipType === 'umum' ? 'Profesi:' : 'Industri:'}</span>
                      <span className="font-bold text-slate-900">{formData.profession}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Domisili:</span>
                      <span className="font-bold text-slate-900">{formData.city}, {formData.province}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Email:</span>
                      <span className="font-bold text-slate-900">{formData.email}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-amber-50 rounded-2xl border border-amber-100">
                  <div className="bg-amber-100 p-2 rounded-lg text-amber-600 shrink-0">
                    <FileText size={18} />
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    Dengan menekan tombol "Daftar Sekarang", Anda menyetujui AD/RT PPTI dan bersedia mengikuti ketentuan organisasi yang berlaku.
                  </p>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="flex gap-4">
                    <button 
                      type="button"
                      onClick={prevStep}
                      className="flex-1 border-2 border-slate-100 text-slate-500 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-all"
                    >
                      Edit Data
                    </button>
                    <button 
                      disabled={isSubmitting}
                      className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-xl shadow-blue-200"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="animate-spin" size={18} /> Memproses...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 size={18} /> Daftar Sekarang
                        </>
                      )}
                    </button>
                  </div>
                  <button 
                    type="button"
                    onClick={onBack}
                    className="w-full py-3 text-slate-400 hover:text-red-500 transition-colors text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <X size={14} /> Batalkan Pendaftaran
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default MembershipForm;
