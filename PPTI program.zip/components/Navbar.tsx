
import React, { useState, useEffect } from 'react';
import { Menu as MenuIcon, X as XIcon, PhoneCall, LogIn } from 'lucide-react';

interface NavbarProps {
  onNavClick?: (href: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavClick }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Beranda', href: '#hero' },
    { label: 'Tentang Kami', href: '#about' },
    { label: 'Keanggotaan', href: '#members' },
  ];

  const handleLinkClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    if (onNavClick) onNavClick(href);
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo & Brand - Kembali ke Desain Teks */}
          <div className="flex items-center group cursor-pointer" onClick={(e) => handleLinkClick(e, '#hero')}>
            <div className="bg-blue-600 p-2 rounded-xl text-white shadow-lg group-hover:rotate-12 transition-transform">
              <LogIn size={24} />
            </div>
            <div className="ml-3 text-left">
              <span className={`block font-black text-xl leading-none tracking-tighter ${scrolled ? 'text-slate-900' : 'text-slate-900'}`}>PPTI</span>
              <span className="block text-[8px] font-black uppercase tracking-[0.3em] text-blue-600">Profesional TI</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-10">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => handleLinkClick(e, item.href)}
                className={`text-sm font-black uppercase tracking-widest transition-colors ${scrolled ? 'text-slate-600 hover:text-blue-600' : 'text-slate-700 hover:text-blue-600'}`}
              >
                {item.label}
              </a>
            ))}
            <div className="h-6 w-px bg-slate-200"></div>
            <button 
              onClick={() => onNavClick?.('#kontak')}
              className="flex items-center gap-2 bg-slate-900 hover:bg-blue-600 text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
            >
              <PhoneCall size={14} /> Hubungi
            </button>
            <button 
              onClick={() => onNavClick?.('#login')}
              className="p-2.5 bg-slate-100 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
              title="Portal Administrasi"
            >
              <LogIn size={20} />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={() => onNavClick?.('#login')}
              className="p-2 bg-slate-100 text-slate-400 rounded-lg"
            >
              <LogIn size={20} />
            </button>
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-900 p-2">
              {isOpen ? <XIcon size={28} /> : <MenuIcon size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden absolute w-full bg-white shadow-2xl transition-all duration-300 overflow-hidden ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
        <div className="px-6 py-8 space-y-6">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => handleLinkClick(e, item.href)}
              className="block text-lg font-black text-slate-900 uppercase tracking-widest hover:text-blue-600"
            >
              {item.label}
            </a>
          ))}
          <button 
            onClick={() => { setIsOpen(false); onNavClick?.('#kontak'); }}
            className="w-full flex items-center justify-center gap-3 bg-blue-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-blue-200"
          >
            <PhoneCall size={18} /> Hubungi Kami
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
