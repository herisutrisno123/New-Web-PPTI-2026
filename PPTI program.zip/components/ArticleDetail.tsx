import React, { useEffect, useState, useMemo } from 'react';
import { ArrowLeft, Calendar, Clock, Tag, ChevronRight, FileSearch, Facebook, Twitter, Linkedin, Search, X } from 'lucide-react';
import { Article } from '../data/articles';
import AdBanner from './AdBanner';

interface ArticleDetailProps {
  article: Article;
  relatedArticles: Article[];
  onBack: () => void;
  onArticleClick: (article: Article) => void;
  onContactClick?: () => void;
}

const ArticleDetail: React.FC<ArticleDetailProps> = ({ 
  article, 
  relatedArticles, 
  onBack, 
  onArticleClick, 
  onContactClick 
}) => {
  const [sidebarSearch, setSidebarSearch] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
    setSidebarSearch('');
  }, [article.id]);

  const filteredSidebarArticles = useMemo(() => {
    if (!sidebarSearch.trim()) return relatedArticles;
    const query = sidebarSearch.toLowerCase();
    return relatedArticles.filter(rel => 
      rel.title.toLowerCase().includes(query) || 
      rel.description.toLowerCase().includes(query)
    );
  }, [sidebarSearch, relatedArticles]);

  return (
    <div className="min-h-screen bg-white pb-20 animate-in fade-in duration-500">
      <div className="relative h-[40vh] md:h-[60vh] w-full overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title} 
          className={`w-full h-full ${article.isGraphic ? 'object-contain bg-slate-50 p-12' : 'object-cover'}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full p-8 md:p-16">
          <div className="max-w-7xl mx-auto">
            <button onClick={onBack} className="mb-6 flex items-center gap-2 text-white/80 hover:text-white font-bold transition-colors group">
              <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> Kembali
            </button>
            <div className="flex items-center gap-3 mb-4">
              <span className="bg-blue-600 text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full">{article.category}</span>
              <span className="text-white/60 text-xs flex items-center gap-1"><Calendar size={12} /> 24 Mei 2024</span>
              <span className="text-white/60 text-xs flex items-center gap-1"><Clock size={12} /> 5 Menit Baca</span>
            </div>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-black text-white leading-tight max-w-4xl">{article.title}</h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 mt-12">
        <div className="flex flex-col lg:flex-row gap-16">
          <div className="lg:w-2/3">
            <article className="prose prose-slate prose-lg max-w-none">
              <p className="text-xl md:text-2xl text-slate-600 font-medium leading-relaxed mb-10 border-l-4 border-blue-600 pl-6 italic">{article.description}</p>
              <div className="text-slate-700 leading-relaxed space-y-6 whitespace-pre-line text-lg">{article.content}</div>
            </article>
            <div className="mt-16 pt-8 border-t border-slate-100 flex flex-wrap items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Bagikan Ke:</span>
                <div className="flex gap-2">
                  <button className="p-2.5 bg-slate-100 rounded-xl text-slate-600 hover:bg-blue-600 hover:text-white transition-all shadow-sm"><Facebook size={18} /></button>
                  <button className="p-2.5 bg-slate-100 rounded-xl text-slate-600 hover:bg-blue-400 hover:text-white transition-all shadow-sm"><Twitter size={18} /></button>
                  <button className="p-2.5 bg-slate-100 rounded-xl text-slate-600 hover:bg-blue-700 hover:text-white transition-all shadow-sm"><Linkedin size={18} /></button>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-xl border border-blue-100 shadow-sm">
                <Tag size={18} className="text-blue-600" />
                <span className="text-sm font-black text-blue-700 uppercase tracking-tight">{article.stats}</span>
              </div>
            </div>
          </div>

          <aside className="lg:w-1/3 space-y-8 lg:sticky lg:top-28 self-start">
             <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <h4 className="font-black text-slate-900 mb-6 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                  <div className="w-1 h-4 bg-blue-600 rounded-full"></div> Tentang Penulis
                </h4>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-200">P</div>
                  <div>
                    <div className="text-sm font-black text-slate-900 leading-tight">Tim Redaksi PPTI</div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Pusat Komunikasi Jakarta</div>
                  </div>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed font-medium italic">Menyajikan wawasan strategis dan standar kompetensi terbaru untuk profesional teknologi informasi di Indonesia.</p>
             </div>

             {/* Ad Space Sidebar */}
             <AdBanner 
               type="sidebar"
               companyName="CyberGuard Security"
               tier="Gold"
               slogan="Layanan Audit Keamanan & Penetrasi Testing Berstandar Internasional."
             />

             <div className="space-y-4">
                <div className="flex items-center justify-between px-1">
                  <h4 className="font-black text-slate-900 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                    Artikel Terkait <div className="h-0.5 w-8 bg-blue-600 rounded-full"></div>
                  </h4>
                </div>
                {relatedArticles.length > 0 && (
                  <div className="relative mb-4 group">
                    <Search className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${sidebarSearch ? 'text-blue-600' : 'text-slate-400 group-focus-within:text-blue-600'}`} size={16} />
                    <input 
                      type="text"
                      placeholder="Cari artikel lain..."
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 pl-11 pr-10 focus:border-blue-600 focus:outline-none focus:bg-white transition-all text-xs font-medium"
                      value={sidebarSearch}
                      onChange={(e) => setSidebarSearch(e.target.value)}
                    />
                    {sidebarSearch && <button onClick={() => setSidebarSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors"><X size={14} /></button>}
                  </div>
                )}
                
                <div className="space-y-3">
                  {filteredSidebarArticles.length > 0 ? (
                    filteredSidebarArticles.map((rel) => (
                      <button 
                        key={rel.id}
                        onClick={() => onArticleClick(rel)}
                        className="w-full flex gap-4 p-3 bg-white rounded-3xl border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all group text-left items-center"
                      >
                        <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 bg-slate-100 border border-slate-50">
                          <img 
                            src={rel.image} 
                            alt={rel.title} 
                            className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${rel.isGraphic ? 'object-contain p-2' : 'object-cover'}`} 
                          />
                        </div>
                        <div className="flex flex-col justify-center flex-1 pr-2">
                          <span className="text-[9px] font-black text-blue-600 uppercase tracking-tighter mb-1 flex items-center gap-1"><Tag size={8} /> {rel.category}</span>
                          <h5 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors">{rel.title}</h5>
                          <div className="flex items-center gap-1.5 text-[9px] text-slate-400 font-bold uppercase tracking-tight mt-1.5">Baca <ChevronRight size={10} className="group-hover:translate-x-1 transition-transform" /></div>
                        </div>
                      </button>
                    ))
                  ) : (
                    <div className="bg-slate-50 p-6 rounded-3xl border border-dashed border-slate-200 text-center">
                      <FileSearch className="mx-auto text-slate-300 mb-2" size={24} />
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tidak ada hasil</p>
                    </div>
                  )}
                </div>
             </div>
             
             <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-blue-200 relative overflow-hidden group">
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
                <h4 className="font-bold text-xl mb-4 relative z-10 leading-tight">Butuh Konsultasi Strategis?</h4>
                <p className="text-sm text-blue-100 mb-8 leading-relaxed relative z-10 opacity-90">Hubungi pakar PPTI untuk diskusi seputar transformasi digital dan standar kompetensi organisasi Anda.</p>
                <button onClick={onContactClick} className="w-full bg-white text-blue-600 py-4 rounded-2xl font-black text-sm hover:bg-blue-50 transition-all relative z-10 shadow-lg active:scale-95">Hubungi Kami</button>
             </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetail;