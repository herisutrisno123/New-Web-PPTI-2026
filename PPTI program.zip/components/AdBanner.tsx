import React from 'react';
import { ExternalLink, Megaphone, ShieldCheck } from 'lucide-react';

interface AdBannerProps {
  type: 'horizontal' | 'sidebar' | 'footer';
  companyName: string;
  tier: 'Platinum' | 'Gold' | 'Silver';
  slogan: string;
  ctaLink?: string;
}

const AdBanner: React.FC<AdBannerProps> = ({ type, companyName, tier, slogan, ctaLink = "#" }) => {
  const tierColor = {
    Platinum: 'bg-slate-900 text-blue-400',
    Gold: 'bg-amber-500 text-white',
    Silver: 'bg-slate-300 text-slate-800'
  };

  if (type === 'sidebar') {
    return (
      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden group hover:shadow-md transition-shadow">
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
            <Megaphone size={10} /> Iklan Anggota
          </span>
          <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${tierColor[tier]}`}>
            {tier}
          </span>
        </div>
        <div className="p-6">
          <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform">
             <ShieldCheck size={32} className="text-blue-600" />
          </div>
          <h5 className="text-sm font-black text-slate-900 text-center mb-2">{companyName}</h5>
          <p className="text-[11px] text-slate-500 text-center leading-relaxed mb-4 line-clamp-2">
            {slogan}
          </p>
          <a 
            href={ctaLink}
            className="w-full py-2.5 bg-blue-600 text-white text-[10px] font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
          >
            Kunjungi Produk <ExternalLink size={12} />
          </a>
        </div>
      </div>
    );
  }

  if (type === 'footer') {
    return (
      <div className="max-w-7xl mx-auto px-4 mb-12">
        <div className="bg-slate-100 rounded-[2.5rem] p-6 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-200/50">
          <div className="flex items-center gap-6">
            <div className="bg-white p-4 rounded-3xl shadow-sm hidden sm:block">
               <ShieldCheck size={40} className="text-blue-600" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Sponsor Utama PPTI</span>
                <span className={`text-[9px] font-black px-2 py-0.5 rounded-md uppercase ${tierColor[tier]}`}>
                  {tier} Member
                </span>
              </div>
              <h4 className="text-xl font-black text-slate-900">{companyName}</h4>
              <p className="text-sm text-slate-500 mt-1">{slogan}</p>
            </div>
          </div>
          <a 
            href={ctaLink}
            className="bg-white text-slate-900 px-8 py-3 rounded-2xl font-bold text-sm hover:bg-blue-600 hover:text-white transition-all shadow-sm flex items-center gap-2"
          >
            Info Selengkapnya <ExternalLink size={16} />
          </a>
        </div>
      </div>
    );
  }

  // Default: Horizontal Banner
  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-[2.5rem] p-8 border border-blue-100 relative overflow-hidden group mb-12">
      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Megaphone size={120} />
      </div>
      <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
        <div className="bg-white p-6 rounded-[2rem] shadow-xl shadow-blue-200/20 shrink-0">
           <ShieldCheck size={48} className="text-blue-600" />
        </div>
        <div className="flex-1 text-center md:text-left">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mb-2">
            <span className="bg-blue-600 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
              Iklan Mitra Perusahaan
            </span>
            <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${tierColor[tier]}`}>
              {tier}
            </span>
          </div>
          <h4 className="text-2xl font-black text-slate-900 mb-2">{companyName}</h4>
          <p className="text-slate-600 font-medium leading-relaxed max-w-2xl italic">
            "{slogan}"
          </p>
        </div>
        <a 
          href={ctaLink}
          className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95 whitespace-nowrap"
        >
          Lihat Detail Layanan
        </a>
      </div>
    </div>
  );
};

export default AdBanner;