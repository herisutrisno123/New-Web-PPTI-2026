import React, { useState, useEffect } from 'react';
import { Users, Eye, Globe, Zap } from 'lucide-react';

const VisitorStats: React.FC = () => {
  // Simulasi data statistik (dalam aplikasi nyata ini diambil dari API/Analytics)
  const [stats, setStats] = useState({
    total: 125430,
    today: 1204,
    online: 42,
    hits: 540122
  });

  // Efek simulasi angka online yang berubah sedikit
  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        online: Math.max(30, prev.online + Math.floor(Math.random() * 5) - 2)
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const statItems = [
    { 
      label: 'Total Pengunjung', 
      value: stats.total.toLocaleString('id-ID'), 
      icon: <Users className="text-blue-600" size={24} />,
      suffix: '+'
    },
    { 
      label: 'Kunjungan Hari Ini', 
      value: stats.today.toLocaleString('id-ID'), 
      icon: <Zap className="text-amber-500" size={24} />,
      suffix: ''
    },
    { 
      label: 'Pengguna Online', 
      value: stats.online.toLocaleString('id-ID'), 
      icon: <Globe className="text-green-600" size={24} />,
      suffix: ''
    },
    { 
      label: 'Total Hits', 
      value: stats.hits.toLocaleString('id-ID'), 
      icon: <Eye className="text-purple-600" size={24} />,
      suffix: '+'
    }
  ];

  return (
    <section className="bg-slate-50 border-y border-slate-100 py-20 relative overflow-hidden">
      {/* Efek cahaya dekoratif yang lebih halus untuk latar terang */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-400/5 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-indigo-400/5 rounded-full blur-[100px]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {statItems.map((item, idx) => (
            <div 
              key={idx} 
              className="flex flex-col items-center text-center p-6 reveal reveal-up group transition-all"
              style={{ transitionDelay: `${idx * 100}ms` }}
            >
              <div className="bg-white p-5 rounded-3xl mb-6 shadow-sm border border-slate-100 group-hover:shadow-xl group-hover:scale-110 group-hover:-translate-y-1 transition-all duration-500">
                {item.icon}
              </div>
              <div className="text-4xl font-black text-slate-900 mb-2 tracking-tight">
                {item.value}<span className="text-blue-600">{item.suffix}</span>
              </div>
              <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 py-1.5 bg-white rounded-full border border-slate-100 shadow-sm">
                {item.label}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 pt-10 border-t border-slate-200/60 text-center">
          <div className="inline-flex items-center gap-2 px-6 py-2 bg-blue-600/5 rounded-full border border-blue-100">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <p className="text-[10px] font-black text-blue-800 uppercase tracking-[0.3em]">
              Real-time Analysis • <span className="opacity-60">PPTI Digital Analytics System</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VisitorStats;