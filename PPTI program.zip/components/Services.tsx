
import React from 'react';
import { BookOpen, Network, Briefcase, Code, BarChart3, Award } from 'lucide-react';

const services = [
  {
    title: 'Sertifikasi Profesi',
    description: 'Program standarisasi dan sertifikasi keahlian TI berstandar internasional untuk para anggota.',
    icon: <Award className="text-blue-600" size={32} />
  },
  {
    title: 'Networking & Kolaborasi',
    description: 'Wadah bertemu dengan ribuan profesional TI dan pemimpin industri teknologi di Indonesia.',
    icon: <Network className="text-blue-600" size={32} />
  },
  {
    title: 'Workshop & Webinar',
    description: 'Update rutin perkembangan teknologi terbaru lewat sesi edukasi dari para pakar industri.',
    icon: <BookOpen className="text-blue-600" size={32} />
  },
  {
    title: 'Job Board Eksklusif',
    description: 'Akses khusus lowongan pekerjaan di perusahaan teknologi ternama bagi anggota terdaftar.',
    icon: <Briefcase className="text-blue-600" size={32} />
  },
  {
    title: 'Advokasi Karir',
    description: 'Pendampingan dan dukungan untuk pertumbuhan karir profesional TI di Indonesia.',
    icon: <Code className="text-blue-600" size={32} />
  },
  {
    title: 'Riset & Data TI',
    description: 'Akses ke laporan riset tren pasar dan teknologi informasi terbaru di kawasan regional.',
    icon: <BarChart3 className="text-blue-600" size={32} />
  },
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal reveal-up">
          <h2 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-4">Layanan Unggulan</h2>
          <h3 className="text-4xl font-extrabold text-slate-900 sm:text-5xl">Program & Manfaat Anggota</h3>
          <p className="mt-4 text-slate-600 max-w-2xl mx-auto text-lg">
            Kami menyediakan berbagai fasilitas untuk mendukung pertumbuhan ekosistem profesional TI di Indonesia.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div 
              key={idx} 
              className={`bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-2 transition-all group reveal reveal-up delay-${(idx % 3) * 100 + 100}`}
            >
              <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
                <div className="group-hover:text-white transition-colors">
                  {service.icon}
                </div>
              </div>
              <h4 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h4>
              <p className="text-slate-500 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
