import React from 'react';
import { ArrowUpRight, ShieldCheck, Tag } from 'lucide-react';
import { articles, Article } from '../data/articles';
import AdBanner from './AdBanner';

interface LatestInfoProps {
  onArticleClick?: (article: Article) => void;
  onConsultationClick?: () => void;
  onViewAllClick?: () => void;
}

const LatestInfo: React.FC<LatestInfoProps> = ({ onArticleClick, onConsultationClick, onViewAllClick }) => {
  const featuredArticles = articles.slice(0, 6);

  return (
    <section className="pt-10 pb-6 bg-slate-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-600/5 -skew-x-12 translate-x-1/2"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 reveal reveal-up">
          <div className="max-w-2xl">
            <h2 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-4">Wawasan & Program</h2>
            <h3 className="text-4xl font-extrabold text-slate-900 sm:text-5xl tracking-tight">Informasi Terkini</h3>
            <p className="mt-4 text-slate-600 text-lg">
              Inisiatif terbaru PPTI dalam mendukung akselerasi digital dan tata kelola teknologi di Indonesia.
            </p>
          </div>
          <button 
            onClick={onViewAllClick}
            className="group flex items-center gap-2 text-blue-600 font-bold hover:text-blue-700 transition-colors"
          >
            Lihat Semua Berita <ArrowUpRight size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {featuredArticles.map((item, idx) => (
            <div 
              key={item.id} 
              className="group bg-white rounded-[2.5rem] overflow-hidden shadow-sm border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 reveal reveal-up flex flex-col"
              style={{ transitionDelay: `${idx * 150}ms` }}
            >
              <div className={`h-48 relative overflow-hidden ${item.isGraphic ? 'bg-slate-50 p-6' : 'bg-slate-100'}`}>
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className={`w-full h-full transition-transform duration-700 group-hover:scale-110 ${item.isGraphic ? 'object-contain' : 'object-cover'}`} 
                  loading="lazy"
                />
                {!item.isGraphic && <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>}
              </div>
              
              <div className="p-8 flex flex-col flex-1 justify-between">
                <div>
                  <div className="bg-blue-50 w-14 h-14 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
                    <div className="group-hover:text-white transition-colors">
                      {item.icon}
                    </div>
                  </div>
                  <h4 className="text-2xl font-black text-slate-900 mb-4 leading-tight group-hover:text-blue-600 transition-colors line-clamp-2">
                    {item.title}
                  </h4>
                  <p className="text-slate-500 text-sm leading-relaxed mb-6 line-clamp-3">
                    {item.description}
                  </p>
                </div>
                
                <div className="pt-6 border-t border-slate-50 flex items-center justify-end gap-3">
                  <div className="flex items-center gap-1.5 text-[9px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-2.5 py-1.5 rounded-lg border border-blue-100 shadow-sm">
                    <Tag size={12} className="text-blue-500" />
                    {item.category}
                  </div>
                  <button 
                    onClick={() => onArticleClick && onArticleClick(item)}
                    className="text-blue-600 font-bold text-sm flex items-center gap-1 group/btn hover:bg-blue-600 hover:text-white px-3 py-1.5 rounded-lg transition-all"
                  >
                    Selengkapnya 
                    <ArrowUpRight size={14} className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Space Iklan Horizontal (Beranda) */}
        <div className="reveal reveal-up">
          <AdBanner 
            type="horizontal"
            companyName="PT. Tekno Solusi Indonesia"
            tier="Platinum"
            slogan="Infrastruktur Cloud Aman & Terpercaya untuk Akselerasi Bisnis Digital Anda."
          />
        </div>

        {/* CaaS Integration Mini Banner */}
        <div className="mt-12 p-8 bg-slate-900 rounded-[2rem] text-white flex flex-col md:flex-row items-center justify-between gap-8 reveal reveal-up delay-300">
          <div className="flex items-center gap-6">
            <div className="bg-blue-600 p-4 rounded-2xl">
              <ShieldCheck size={32} />
            </div>
            <div>
              <h5 className="text-xl font-bold">Maturity Assessment (CaaS)</h5>
              <p className="text-slate-400 text-sm max-w-md">Kami membantu organisasi mengukur kesiapan teknologi melalui kerangka kerja Capability as a Service.</p>
            </div>
          </div>
          <button 
            onClick={onConsultationClick}
            className="bg-white text-slate-900 px-8 py-3 rounded-xl font-bold hover:bg-blue-50 transition-colors whitespace-nowrap"
          >
            Konsultasi Program
          </button>
        </div>
      </div>
    </section>
  );
};

export default LatestInfo;