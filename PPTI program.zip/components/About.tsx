import React from 'react';
import { Target, Award, CheckCircle2, ShieldCheck, Landmark, BookOpen, Users2, Rocket, History, Scale } from 'lucide-react';

const About: React.FC = () => {
  const missionPoints = [
    "Menghasilkan solusi inovatif dalam bidang Teknologi Informasi.",
    "Membangun hubungan yang baik dengan para pemangku kepentingan di sektor Pemerintahan dan sektor swasta.",
    "Membentuk dan mengembangkan anggota PPTI menjadi kompeten dan profesional di bidangnya.",
    "Membangun hubungan internasional sesuai solusi inovatif."
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Section Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24 reveal reveal-up">
          <div className="inline-block bg-blue-50 px-4 py-2 rounded-xl text-blue-600 font-black text-xs uppercase tracking-[0.2em] mb-4">
            Official Profile
          </div>
          <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight mb-6">
            Profil Organisasi PPTI
          </h2>
          <p className="text-xl text-slate-500 max-w-3xl mx-auto font-medium leading-relaxed">
            Mengenal lebih dekat Perkumpulan Profesional Teknologi Informasi sebagai wadah pemersatu pakar digital Indonesia.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Identity Column */}
          <div className="space-y-12 reveal reveal-right">
            <div className="space-y-8">
              <div className="flex items-center gap-4 group">
                <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200 group-hover:rotate-6 transition-transform">
                  <ShieldCheck size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900">Identitas Keprofesian</h3>
                  <p className="text-slate-500 font-bold text-sm uppercase tracking-widest">Profesional & Terintegrasi</p>
                </div>
              </div>

              <p className="text-2xl font-bold text-slate-800 leading-snug">
                PPTI adalah <span className="text-blue-600">organisasi keprofesian</span> di bidang Teknologi Informasi yang didirikan di Jakarta pada <span className="bg-blue-50 px-2 rounded-lg">1 Juni 2018</span>.
              </p>

              <p className="text-lg text-slate-600 leading-relaxed">
                Organisasi ini bersifat <span className="font-bold text-slate-900 underline decoration-blue-500 decoration-4">Mandiri dan Non-Profit</span>. Dibentuk sebagai jembatan strategis untuk meningkatkan standar kompetensi digital nasional di tengah percepatan teknologi global.
              </p>
            </div>

            {/* Legal Card */}
            <div className="bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 w-40 h-40 bg-blue-600/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
              <div className="flex items-start gap-6 relative z-10">
                <div className="bg-white/10 p-5 rounded-3xl border border-white/10 text-blue-400">
                  <Landmark size={32} />
                </div>
                <div>
                  <h4 className="text-xs font-black text-blue-400 uppercase tracking-[0.2em] mb-3">Legalitas Organisasi</h4>
                  <div className="text-2xl font-black mb-2 tracking-tight">Kemenkumham RI</div>
                  <div className="text-blue-100/60 font-mono text-sm mb-4">SK NO: AHU-0007328.AH.01.07.Tahun 2018</div>
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase text-white/40">
                    <History size={12} /> Terdaftar Resmi Sejak Juni 2018
                  </div>
                </div>
              </div>
            </div>

            {/* Values Grid */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: 'Mandiri', icon: <Users2 size={24} />, bg: 'bg-blue-50', color: 'text-blue-600' },
                { label: 'Non-Profit', icon: <Rocket size={24} />, bg: 'bg-green-50', color: 'text-green-600' },
                { label: 'Profesional', icon: <Scale size={24} />, bg: 'bg-amber-50', color: 'text-amber-600' }
              ].map((val, i) => (
                <div key={i} className={`${val.bg} p-6 rounded-3xl text-center border border-white group hover:shadow-lg transition-all`}>
                  <div className={`${val.color} mb-3 flex justify-center group-hover:scale-110 transition-transform`}>
                    {val.icon}
                  </div>
                  <div className="text-xs font-black text-slate-900 uppercase tracking-widest">{val.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Vision/Mission Column */}
          <div className="space-y-8 reveal reveal-left delay-200">
            {/* Visi Section */}
            <div className="bg-white p-12 rounded-[3.5rem] border-2 border-slate-50 shadow-xl shadow-slate-100 relative group overflow-hidden">
              <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-blue-50 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="flex items-center gap-5 mb-8">
                <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                  <Target size={32} />
                </div>
                <h4 className="text-3xl font-black text-slate-900 tracking-tight">Visi PPTI</h4>
              </div>
              <p className="text-2xl font-bold text-slate-700 leading-relaxed italic border-l-8 border-blue-600 pl-8">
                "Menjadi organisasi yang terpercaya, profesional, dan berdaya saing nasional dan internasional sesuai profesi."
              </p>
            </div>

            {/* Misi Section */}
            <div className="bg-slate-50 p-12 rounded-[3.5rem] border border-slate-200 relative">
              <div className="flex items-center gap-5 mb-10">
                <div className="bg-white p-4 rounded-2xl text-blue-600 shadow-sm border border-slate-100">
                  <Award size={32} />
                </div>
                <h4 className="text-3xl font-black text-slate-900 tracking-tight">Misi Strategis</h4>
              </div>
              <ul className="space-y-6">
                {missionPoints.map((point, index) => (
                  <li key={index} className="flex items-start gap-5 group">
                    <div className="mt-1.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white shadow-md group-hover:scale-125 transition-transform">
                      <CheckCircle2 size={14} />
                    </div>
                    <span className="text-lg text-slate-700 font-bold leading-tight group-hover:text-blue-700 transition-colors">
                      {point}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;