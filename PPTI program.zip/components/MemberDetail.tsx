
import React, { useEffect } from 'react';
import { Member } from '../types';
import { ArrowLeft, MapPin, Linkedin, Github, Twitter, Briefcase, Award, CreditCard, ShieldCheck, ExternalLink } from 'lucide-react';

interface MemberDetailProps {
  member: Member;
  onBack: () => void;
  onContactClick?: () => void;
}

const MemberDetail: React.FC<MemberDetailProps> = ({ member, onBack, onContactClick }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white pb-20 animate-in fade-in duration-500">
      {/* Navigation Header - Adjusted top to sit below the fixed Navbar */}
      <div className="bg-white/90 backdrop-blur-md border-b border-slate-100 py-4 sticky top-[64px] md:top-[72px] z-40 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-600 hover:text-blue-600 font-black text-sm uppercase tracking-widest transition-all group py-2"
          >
            <div className="bg-slate-100 group-hover:bg-blue-600 group-hover:text-white p-2 rounded-xl transition-colors">
              <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
            </div>
            Kembali ke Direktori
          </button>
          <div className="hidden sm:flex items-center gap-2 text-[10px] font-black text-blue-600 tracking-[0.2em] uppercase bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-100">
            <ShieldCheck size={14} /> Anggota Terverifikasi
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pt-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
          
          {/* Sidebar Section: Membership Card & Essential Info */}
          <div className="lg:w-1/3">
            <div className="lg:sticky lg:top-40 space-y-10">
              {/* Membership Card Visual - Large Display */}
              <div className="relative group">
                <div className="absolute inset-0 bg-blue-600 rounded-3xl blur-2xl opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="relative transform transition-all duration-700 hover:scale-105 hover:-rotate-1">
                  <img 
                    src={member.avatar} 
                    alt={`ID Card ${member.name}`} 
                    className="w-full h-auto rounded-[2rem] shadow-[0_32px_64px_-16px_rgba(0,56,168,0.3)] border-4 border-white"
                  />
                  <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-2 rounded-xl border border-white/20">
                    <CreditCard className="text-white" size={24} />
                  </div>
                </div>
              </div>

              {/* Quick Info Below Card */}
              <div className="space-y-6 text-center lg:text-left bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100">
                <div>
                  <h1 className="text-3xl font-black text-slate-900 leading-tight mb-2">{member.name}</h1>
                  <p className="text-lg font-bold text-blue-600">{member.title}</p>
                  <p className="text-xs font-mono font-bold text-slate-400 mt-2 uppercase tracking-widest">{member.id}</p>
                </div>
                
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-center lg:justify-start gap-3 text-slate-500 font-bold text-sm">
                    <MapPin size={18} className="text-blue-500" />
                    {member.location}
                  </div>
                  <div className="flex items-center justify-center lg:justify-start gap-3 text-slate-500 font-bold text-sm">
                    <Award size={18} className="text-amber-500" />
                    PPTI Elite Member
                  </div>
                </div>
                
                <div className="pt-4 flex justify-center lg:justify-start gap-3">
                  {member.socials.linkedin && (
                    <a href={member.socials.linkedin} target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-2xl text-slate-400 hover:bg-blue-600 hover:text-white hover:scale-110 transition-all shadow-sm border border-slate-200">
                      <Linkedin size={20} />
                    </a>
                  )}
                  {member.socials.github && (
                    <a href={member.socials.github} target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-2xl text-slate-400 hover:bg-slate-900 hover:text-white hover:scale-110 transition-all shadow-sm border border-slate-200">
                      <Github size={20} />
                    </a>
                  )}
                  {member.socials.twitter && (
                    <a href={member.socials.twitter} target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-2xl text-slate-400 hover:bg-blue-400 hover:text-white hover:scale-110 transition-all shadow-sm border border-slate-200">
                      <Twitter size={20} />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Section */}
          <div className="lg:w-2/3 space-y-16">
            <section className="reveal revealed">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-4">
                Pernyataan Profesional
                <div className="flex-1 h-px bg-slate-100"></div>
              </h2>
              <p className="text-xl md:text-2xl text-slate-600 font-medium leading-relaxed mb-10 border-l-4 border-blue-600 pl-6 italic">
                "{member.bio}"
              </p>
            </section>

            <section className="reveal revealed">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-8 flex items-center gap-4">
                Keahlian Teknis
                <div className="flex-1 h-px bg-slate-100"></div>
              </h2>
              <div className="flex flex-wrap gap-3">
                {member.skills.map((skill, idx) => (
                  <div 
                    key={skill} 
                    className="px-6 py-3 bg-white text-slate-700 rounded-2xl text-sm font-bold border-2 border-slate-50 shadow-sm hover:border-blue-100 hover:text-blue-600 transition-all"
                    style={{ animationDelay: `${idx * 50}ms` }}
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </section>

            <section className="reveal revealed">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-10 flex items-center gap-4">
                Pengalaman Kerja
                <div className="flex-1 h-px bg-slate-100"></div>
              </h2>
              <div className="space-y-10">
                {member.experience.map((exp, idx) => (
                  <div key={idx} className="flex gap-8 items-start relative">
                    {idx !== member.experience.length - 1 && (
                      <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-slate-100"></div>
                    )}
                    <div className="bg-blue-50 p-3.5 rounded-2xl shrink-0 z-10 text-blue-600 shadow-sm">
                      <Briefcase size={22} />
                    </div>
                    <div className="pt-1">
                      <div className="inline-block px-3 py-1 bg-blue-600 text-white text-[10px] font-black rounded-lg mb-3 shadow-md shadow-blue-100">
                        {exp.year}
                      </div>
                      <h4 className="text-xl font-black text-slate-900 mb-1">{exp.role}</h4>
                      <p className="text-slate-500 font-semibold">{exp.company}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Interaction Card */}
            <div className="bg-slate-900 rounded-[3rem] p-10 md:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl relative overflow-hidden group">
              <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-blue-600/20 rounded-full blur-3xl"></div>
              <div className="relative z-10">
                <h4 className="text-2xl font-black mb-3">Terhubung dengan {member.name.split(' ')[0]}</h4>
                <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
                  Gunakan jaringan PPTI untuk menjalin kolaborasi strategis atau mengundang pakar ini dalam proyek Anda.
                </p>
              </div>
              <button 
                onClick={onContactClick}
                className="bg-blue-600 text-white px-10 py-5 rounded-2xl font-black text-sm hover:bg-blue-500 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-blue-900/40 relative z-10 flex items-center gap-3"
              >
                Hubungi via PPTI <ExternalLink size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberDetail;
