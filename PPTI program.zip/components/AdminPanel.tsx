
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Settings, 
  LogOut, 
  Search, 
  Edit3, 
  Plus, 
  Trash2, 
  Save, 
  X, 
  CheckCircle2,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Users,
  TrendingUp,
  Files,
  ArrowRight,
  Filter,
  CreditCard,
  MapPin,
  Briefcase,
  Award,
  PlusCircle,
  Tags,
  Check,
  CheckCircle,
  Upload,
  RefreshCw,
  Camera,
  UserCog,
  UserPlus,
  Shield,
  Mail,
  ChevronDown,
  Lock,
  Eye,
  EyeOff,
  Key
} from 'lucide-react';
import { articles as initialArticles, Article } from '../data/articles';
import { Member } from '../types';
import { getMembershipCard } from '../data/members';

type TabType = 'dashboard' | 'articles' | 'members' | 'skills' | 'users';

interface AdminUser {
  id: string;
  username: string;
  password: string;
  role: 'Super Admin' | 'Editor';
  email: string;
  status: 'Aktif' | 'Nonaktif';
  permissions: TabType[];
}

interface AdminPanelProps {
  onLogout: () => void;
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  allSkills: string[];
  setAllSkills: React.Dispatch<React.SetStateAction<string[]>>;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout, members, setMembers, allSkills, setAllSkills }) => {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [articles, setArticles] = useState<Article[]>(initialArticles);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [isCustomAvatar, setIsCustomAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // User Management State
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([
    { id: 'ADM-001', username: 'administrasi', password: 'admin123', role: 'Super Admin', email: 'admin@ppti.or.id', status: 'Aktif', permissions: ['dashboard', 'articles', 'members', 'skills', 'users'] },
    { id: 'ADM-002', username: 'editor_konten', password: 'editor123', role: 'Editor', email: 'editor@ppti.or.id', status: 'Aktif', permissions: ['dashboard', 'articles'] },
  ]);

  const [isCreatingAdmin, setIsCreatingAdmin] = useState(false);
  const [editingAdminId, setEditingAdminId] = useState<string | null>(null);
  const [newAdminForm, setNewAdminForm] = useState<Omit<AdminUser, 'id' | 'status'>>({
    username: '',
    password: '',
    email: '',
    role: 'Editor',
    permissions: ['dashboard', 'articles']
  });

  // Skills Management States
  const [newSkillName, setNewSkillName] = useState('');
  const [skillToEdit, setSkillToEdit] = useState<{old: string, new: string} | null>(null);
  
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'skill_added'>('idle');

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError('');

    setTimeout(() => {
      // Mencocokkan dengan data admin yang ada di state berdasarkan username dan password unik
      const foundUser = adminUsers.find(u => u.username === loginForm.username && u.password === loginForm.password);
      
      if (foundUser) {
        if (foundUser.status === 'Nonaktif') {
          setLoginError('Akun Anda dinonaktifkan. Silakan hubungi Super Admin.');
        } else {
          setCurrentUser(foundUser);
          setIsLoggedIn(true);
          // Set tab pertama yang diperbolehkan
          setActiveTab(foundUser.permissions[0] || 'dashboard');
        }
      } else {
        setLoginError('Username atau password salah.');
      }
      setIsLoggingIn(false);
    }, 1000);
  };

  // --- User Management ---
  const handleDeleteAdminUser = (id: string) => {
    if (id === currentUser?.id) {
      alert('Anda tidak dapat menghapus akun Anda sendiri.');
      return;
    }
    if (window.confirm('Hapus akses administrator untuk pengguna ini?')) {
      setAdminUsers(prev => prev.filter(u => u.id !== id));
    }
  };

  const handleCreateAdminUser = () => {
    setNewAdminForm({ username: '', password: '', email: '', role: 'Editor', permissions: ['dashboard', 'articles'] });
    setEditingAdminId(null);
    setIsCreatingAdmin(true);
    setShowPassword(false);
  };

  const handleEditAdminUser = (user: AdminUser) => {
    setNewAdminForm({ 
      username: user.username, 
      password: user.password,
      email: user.email, 
      role: user.role, 
      permissions: [...user.permissions] 
    });
    setEditingAdminId(user.id);
    setIsCreatingAdmin(true);
    setShowPassword(false);
  };

  const handleRoleChange = (role: AdminUser['role']) => {
    let defaultPerms: TabType[] = ['dashboard'];
    if (role === 'Super Admin') defaultPerms = ['dashboard', 'articles', 'members', 'skills', 'users'];
    if (role === 'Editor') defaultPerms = ['dashboard', 'articles'];
    
    setNewAdminForm({ ...newAdminForm, role, permissions: defaultPerms });
  };

  const togglePermission = (perm: TabType) => {
    const current = newAdminForm.permissions;
    const updated = current.includes(perm)
      ? current.filter(p => p !== perm)
      : [...current, perm];
    setNewAdminForm({ ...newAdminForm, permissions: updated });
  };

  const handleSaveAdminUser = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    setTimeout(() => {
      if (editingAdminId) {
        setAdminUsers(prev => prev.map(u => u.id === editingAdminId ? { ...u, ...newAdminForm } : u));
      } else {
        const newId = `ADM-${Math.floor(100 + Math.random() * 900)}`;
        const newUser: AdminUser = {
          ...newAdminForm,
          id: newId,
          status: 'Aktif'
        };
        setAdminUsers([newUser, ...adminUsers]);
      }
      
      setIsSaving(false);
      setSaveStatus('success');
      
      setTimeout(() => {
        setIsCreatingAdmin(false);
        setSaveStatus('idle');
        setEditingAdminId(null);
      }, 1000);
    }, 1200);
  };

  // --- Article Management ---
  const handleCreateNewArticle = () => {
    const newArticle: Article = {
      id: 'ART-' + Math.random().toString(36).substr(2, 7).toUpperCase(),
      title: '',
      category: 'Berita',
      description: '',
      content: '',
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800',
      stats: 'Baru Dibuat',
      icon: <FileText size={32} />
    };
    setEditingArticle(newArticle);
  };

  const handleSaveArticle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArticle) return;
    setIsSaving(true);
    setTimeout(() => {
      const isNew = !articles.some(a => a.id === editingArticle.id);
      if (isNew) {
        setArticles([editingArticle, ...articles]);
      } else {
        setArticles(articles.map(a => a.id === editingArticle.id ? editingArticle : a));
      }
      setIsSaving(false);
      setSaveStatus('success');
      setTimeout(() => { setSaveStatus('idle'); setEditingArticle(null); }, 1500);
    }, 1200);
  };

  const handleDeleteArticle = (id: string) => {
    if (window.confirm('Hapus artikel ini secara permanen?')) {
      setArticles(articles.filter(a => a.id !== id));
    }
  };

  // --- Member Management ---
  const handleCreateNewMember = () => {
    const newMember: Member = {
      id: 'PPTI-' + new Date().getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000),
      name: '',
      title: '',
      avatar: '',
      bio: '',
      location: 'Jakarta, Indonesia',
      skills: [],
      experience: [],
      socials: {}
    };
    newMember.avatar = getMembershipCard(newMember.name, newMember.id, newMember.title);
    setEditingMember(newMember);
    setIsCustomAvatar(false);
  };

  const handleEditMember = (member: Member) => {
    setEditingMember(member);
    // Check if current avatar is the auto-generated one
    const autoGen = getMembershipCard(member.name, member.id, member.title);
    setIsCustomAvatar(member.avatar !== autoGen);
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember) return;
    setIsSaving(true);
    
    // Use uploaded avatar if custom, otherwise regenerate based on potentially updated fields
    const finalAvatar = isCustomAvatar 
      ? editingMember.avatar 
      : getMembershipCard(editingMember.name, editingMember.id, editingMember.title);

    const finalMember = {
      ...editingMember,
      avatar: finalAvatar
    };

    setTimeout(() => {
      const isNew = !members.some(m => m.id === finalMember.id);
      if (isNew) {
        setMembers([finalMember, ...members]);
      } else {
        setMembers(members.map(m => m.id === finalMember.id ? finalMember : m));
      }
      setIsSaving(false);
      setSaveStatus('success');
      setTimeout(() => { setSaveStatus('idle'); setEditingMember(null); }, 1500);
    }, 1200);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingMember) return;

    if (!file.type.startsWith('image/')) {
      alert('Hanya file gambar yang diperbolehkan.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setEditingMember({ ...editingMember, avatar: base64String });
      setIsCustomAvatar(true);
    };
    reader.readAsDataURL(file);
  };

  const handleResetAvatar = () => {
    if (!editingMember) return;
    const autoGen = getMembershipCard(editingMember.name, editingMember.id, editingMember.title);
    setEditingMember({ ...editingMember, avatar: autoGen });
    setIsCustomAvatar(false);
  };

  const toggleMemberSkill = (skill: string) => {
    if (!editingMember) return;
    const currentSkills = editingMember.skills;
    const newSkills = currentSkills.includes(skill)
      ? currentSkills.filter(s => s !== skill)
      : [...currentSkills, skill];
    setEditingMember({ ...editingMember, skills: newSkills });
  };

  const handleDeleteMember = (id: string) => {
    if (window.confirm('Hapus anggota ini dari direktori?')) {
      setMembers(members.filter(m => m.id !== id));
    }
  };

  // --- Skills Management ---
  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkillName.trim()) return;
    
    const skillToAdd = newSkillName.trim();
    if (allSkills.some(s => s.toLowerCase() === skillToAdd.toLowerCase())) {
      alert('Keahlian ini sudah ada dalam daftar.');
      return;
    }
    
    setAllSkills(prev => [...prev, skillToAdd].sort());
    setNewSkillName('');
    setSaveStatus('skill_added');
    setTimeout(() => setSaveStatus('idle'), 3000);
  };

  const handleUpdateSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillToEdit || !skillToEdit.new.trim()) return;
    
    const updatedName = skillToEdit.new.trim();
    const oldName = skillToEdit.old;

    // Cek duplikasi
    if (allSkills.some(s => s.toLowerCase() === updatedName.toLowerCase() && s !== oldName)) {
      alert('Nama keahlian ini sudah digunakan.');
      return;
    }

    setAllSkills(prev => prev.map(s => s === oldName ? updatedName : s).sort());
    
    setMembers(prevMembers => prevMembers.map(m => ({
      ...m,
      skills: m.skills.map(s => s === oldName ? updatedName : s)
    })));

    setSkillToEdit(null);
    setSaveStatus('success');
    setTimeout(() => setSaveStatus('idle'), 1500);
  };

  const handleDeleteSkill = (skillName: string) => {
    if (window.confirm(`Hapus "${skillName}" dari daftar standar keahlian? Keahlian ini juga akan dihapus dari profil anggota yang memilikinya.`)) {
      setAllSkills(prev => prev.filter(s => s !== skillName));
      setMembers(prevMembers => prevMembers.map(m => ({
        ...m,
        skills: m.skills.filter(s => s !== skillName)
      })));
    }
  };

  // Filter Logics
  const filteredArticles = articles.filter(a => {
    const matchesSearch = a.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'Semua' || a.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    m.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSkills = allSkills.filter(s => 
    s.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredAdminUsers = adminUsers.filter(u => 
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Helper untuk mengecek permission menu aktif
  const hasAccess = (tab: TabType) => currentUser?.permissions.includes(tab) || currentUser?.role === 'Super Admin';

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full animate-in zoom-in-95 duration-500">
          <div className="text-center mb-10">
            <div className="bg-blue-600 w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-blue-500/20">
              <Settings className="text-white" size={32} />
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight">Panel Kelola PPTI</h1>
            <p className="text-slate-400 mt-2">Masuk untuk memperbarui konten website.</p>
          </div>
          <div className="bg-white rounded-[2.5rem] p-10 shadow-2xl">
            <form onSubmit={handleLogin} className="space-y-6">
              {loginError && (
                <div className="bg-red-50 text-red-600 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold border border-red-100">
                  <AlertCircle size={18} /> {loginError}
                </div>
              )}
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Username</label>
                <input type="text" required placeholder="administrasi" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all font-medium" value={loginForm.username} onChange={e => setLoginForm({...loginForm, username: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Password</label>
                <input type="password" required placeholder="••••••••" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all font-medium" value={loginForm.password} onChange={e => setLoginForm({...loginForm, password: e.target.value})} />
              </div>
              <button disabled={isLoggingIn} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-sm hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 flex items-center justify-center gap-2">
                {isLoggingIn ? <Loader2 className="animate-spin" size={20} /> : 'Masuk Dashboard'}
              </button>
            </form>
          </div>
          <button onClick={onLogout} className="w-full mt-8 bg-white/10 hover:bg-white/20 text-white py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 backdrop-blur-sm border border-white/10">
            <ArrowLeft size={18} /> Batal & Kembali ke Beranda
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className="w-64 bg-slate-900 text-white hidden lg:flex flex-col p-6 fixed h-full z-40">
        <div className="flex items-center gap-3 mb-12 px-2">
          <div className="bg-blue-600 p-2 rounded-xl"><Settings size={20} /></div>
          <span className="font-black text-lg tracking-tight">Admin Portal</span>
        </div>
        <nav className="flex-1 space-y-2">
          {hasAccess('dashboard') && (
            <button onClick={() => { setActiveTab('dashboard'); setSearchQuery(''); }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}><LayoutDashboard size={20} /> Dashboard</button>
          )}
          {hasAccess('articles') && (
            <button onClick={() => { setActiveTab('articles'); setSearchQuery(''); }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeTab === 'articles' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}><FileText size={20} /> Artikel</button>
          )}
          {hasAccess('members') && (
            <button onClick={() => { setActiveTab('members'); setSearchQuery(''); }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeTab === 'members' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}><Users size={20} /> Keanggotaan</button>
          )}
          {hasAccess('skills') && (
            <button onClick={() => { setActiveTab('skills'); setSearchQuery(''); }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeTab === 'skills' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}><Tags size={20} /> Keahlian</button>
          )}
          {hasAccess('users') && (
            <button onClick={() => { setActiveTab('users'); setSearchQuery(''); }} className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeTab === 'users' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}><UserCog size={20} /> Pengguna</button>
          )}
        </nav>
        <div className="pt-6 border-t border-white/10 mb-6">
           <div className="px-4 mb-4">
              <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sesi Aktif:</div>
              <div className="font-bold text-blue-400 text-xs mt-1">@{currentUser?.username}</div>
           </div>
           <button onClick={() => { setIsLoggedIn(false); setCurrentUser(null); onLogout(); }} className="w-full flex items-center gap-4 px-4 py-3 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-xl font-bold text-sm transition-all"><LogOut size={20} /> Keluar</button>
        </div>
      </aside>

      <main className="flex-1 lg:ml-64 p-4 lg:p-10">
        {activeTab === 'dashboard' && (
          <div className="animate-in fade-in duration-500">
            <header className="mb-10">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Dashboard Ringkasan</h2>
              <p className="text-slate-500">Informasi performa dan konten website PPTI saat ini.</p>
            </header>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
              <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="bg-blue-600 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4"><Files size={20} /></div>
                <div className="text-2xl font-black text-slate-900">{articles.length}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Artikel</div>
              </div>
              <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="bg-indigo-600 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4"><Users size={20} /></div>
                <div className="text-2xl font-black text-slate-900">{members.length}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Anggota</div>
              </div>
              <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="bg-amber-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4"><Tags size={20} /></div>
                <div className="text-2xl font-black text-slate-900">{allSkills.length}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jenis Keahlian</div>
              </div>
              <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="bg-slate-800 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4"><Shield size={20} /></div>
                <div className="text-2xl font-black text-slate-900">{adminUsers.length}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Admin</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'articles' && (
          <div className="animate-in fade-in duration-500">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Kelola Konten</h2>
                <p className="text-slate-500">Manajemen artikel berdasarkan kelompok konten.</p>
              </div>
              <button onClick={handleCreateNewArticle} className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all active:scale-95"><Plus size={18} /> Buat Artikel Baru</button>
            </header>
            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
               <table className="w-full text-left">
                 <thead className="bg-slate-50 border-b border-slate-100">
                   <tr>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Judul & Kelompok</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Aksi</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                   {filteredArticles.map((item) => (
                     <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                       <td className="px-8 py-6">
                         <div className="flex items-center gap-4">
                           <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-100 shrink-0"><img src={item.image} alt="" className="w-full h-full object-cover" /></div>
                           <div>
                             <span className="block font-bold text-slate-900 line-clamp-1">{item.title}</span>
                             <span className="text-[9px] font-black text-blue-600 uppercase">{item.category}</span>
                           </div>
                         </div>
                       </td>
                       <td className="px-8 py-6 text-right">
                         <div className="flex justify-end gap-2">
                           <button onClick={() => setEditingArticle(item)} className="p-2 text-slate-400 hover:text-blue-600"><Edit3 size={18} /></button>
                           <button onClick={() => handleDeleteArticle(item.id)} className="p-2 text-slate-400 hover:text-red-600"><Trash2 size={18} /></button>
                         </div>
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </div>
          </div>
        )}

        {activeTab === 'members' && (
          <div className="animate-in fade-in duration-500">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Direktori Anggota</h2>
                <p className="text-slate-500">Kelola data profil profesional yang tampil di direktori website.</p>
              </div>
              <button onClick={handleCreateNewMember} className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all active:scale-95">
                <PlusCircle size={18} /> Daftarkan Anggota Baru
              </button>
            </header>

            <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 mb-8">
              <div className="relative w-full">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input type="text" placeholder="Cari nama atau ID anggota..." className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all text-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
               <table className="w-full text-left">
                 <thead className="bg-slate-50 border-b border-slate-100">
                   <tr>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Identitas & Kartu</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Jabatan</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Lokasi</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Aksi</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                   {filteredMembers.map((member) => (
                     <tr key={member.id} className="hover:bg-slate-50/50 transition-colors">
                       <td className="px-8 py-6">
                         <div className="flex items-center gap-4">
                           <div className="w-14 h-10 rounded-lg overflow-hidden border border-slate-200 shadow-sm shrink-0">
                             <img src={member.avatar} alt="" className="w-full h-full object-cover" />
                           </div>
                           <div>
                             <span className="block font-bold text-slate-900">{member.name}</span>
                             <span className="text-[9px] font-mono text-slate-400 uppercase">{member.id}</span>
                           </div>
                         </div>
                       </td>
                       <td className="px-8 py-6">
                         <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">{member.title}</span>
                       </td>
                       <td className="px-8 py-6">
                         <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                           <MapPin size={12} className="text-slate-300" /> {member.location}
                         </div>
                       </td>
                       <td className="px-8 py-6 text-right">
                         <div className="flex justify-end gap-2">
                           <button onClick={() => handleEditMember(member)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"><Edit3 size={18} /></button>
                           <button onClick={() => handleDeleteMember(member.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"><Trash2 size={18} /></button>
                         </div>
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </div>
          </div>
        )}

        {activeTab === 'skills' && (
          <div className="animate-in fade-in duration-500">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Keahlian & Kompetensi</h2>
                <p className="text-slate-500">Kelola daftar keahlian standar yang dapat dipilih oleh anggota.</p>
              </div>
              <form onSubmit={handleAddSkill} className="flex gap-3 relative">
                <input 
                  type="text" 
                  placeholder="Nama Keahlian Baru..." 
                  className="bg-white border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all text-sm font-bold min-w-[280px] shadow-sm"
                  value={newSkillName}
                  onChange={e => setNewSkillName(e.target.value)}
                />
                <button type="submit" className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black text-sm flex items-center gap-2 hover:bg-blue-700 shadow-xl shadow-blue-100 transition-all active:scale-95">
                  <Plus size={18} /> Tambah Keahlian
                </button>
                {saveStatus === 'skill_added' && (
                  <div className="absolute -bottom-10 left-0 text-green-600 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 animate-in slide-in-from-top-2">
                    <CheckCircle size={14} /> Keahlian Berhasil Ditambahkan!
                  </div>
                )}
              </form>
            </header>

            <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 mb-8">
              <div className="relative w-full">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input type="text" placeholder="Cari keahlian dalam daftar..." className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all text-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
               {filteredSkills.map((skill) => (
                 <div key={skill} className="bg-white p-5 rounded-2xl border border-slate-100 flex items-center justify-between group hover:border-blue-300 hover:shadow-xl hover:-translate-y-1 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-50 p-2.5 rounded-xl text-blue-600 shadow-sm">
                        <Tags size={18} />
                      </div>
                      <span className="text-sm font-black text-slate-800 tracking-tight">{skill}</span>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                      <button 
                        onClick={() => setSkillToEdit({old: skill, new: skill})}
                        className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDeleteSkill(skill)}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                 </div>
               ))}
               {filteredSkills.length === 0 && (
                 <div className="col-span-full py-20 text-center bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
                    <Tags className="mx-auto text-slate-300 mb-4" size={48} strokeWidth={1} />
                    <p className="text-slate-400 font-black uppercase tracking-widest text-xs">Keahlian Tidak Ditemukan</p>
                    <button onClick={() => setSearchQuery('')} className="mt-4 text-blue-600 font-bold text-xs hover:underline">Lihat Semua Keahlian</button>
                 </div>
               )}
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="animate-in fade-in duration-500">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tight">Manajemen Pengguna Admin</h2>
                <p className="text-slate-500">Kelola akses personil internal untuk pengelolaan website.</p>
              </div>
              <button onClick={handleCreateAdminUser} className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-slate-800 shadow-lg transition-all active:scale-95">
                <UserPlus size={18} /> Tambah Admin Baru
              </button>
            </header>

            <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 mb-8">
              <div className="relative w-full">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input type="text" placeholder="Cari username atau email admin..." className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all text-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
               <table className="w-full text-left">
                 <thead className="bg-slate-50 border-b border-slate-100">
                   <tr>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Administrator</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest">Akses Menu</th>
                     <th className="px-8 py-5 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Aksi</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                   {filteredAdminUsers.map((user) => (
                     <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                       <td className="px-8 py-6">
                         <div className="flex items-center gap-4">
                           <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                             <Users size={18} />
                           </div>
                           <div>
                             <span className="block font-bold text-slate-900">{user.username}</span>
                             <div className="flex items-center gap-2">
                               <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${
                                 user.role === 'Super Admin' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'
                               }`}>
                                 {user.role}
                               </span>
                               <span className="text-[10px] text-slate-400 font-medium">{user.email}</span>
                             </div>
                           </div>
                         </div>
                       </td>
                       <td className="px-8 py-6">
                         <div className="flex flex-wrap gap-1">
                           {user.permissions.map(p => (
                             <span key={p} className="bg-slate-50 text-slate-500 text-[8px] font-black uppercase px-2 py-1 rounded-md border border-slate-100">
                               {p === 'dashboard' ? 'Dash' : p === 'articles' ? 'Art' : p === 'members' ? 'Mem' : p === 'skills' ? 'Skill' : 'User'}
                             </span>
                           ))}
                         </div>
                       </td>
                       <td className="px-8 py-6 text-right">
                         <div className="flex justify-end gap-2">
                           <button onClick={() => handleEditAdminUser(user)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"><Edit3 size={18} /></button>
                           {user.id !== 'ADM-001' && (
                             <button onClick={() => handleDeleteAdminUser(user.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"><Trash2 size={18} /></button>
                           )}
                         </div>
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </div>
          </div>
        )}
      </main>

      {/* Modal Tambah/Edit Admin */}
      {isCreatingAdmin && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => !isSaving && setIsCreatingAdmin(false)}></div>
          <div className="relative bg-white w-full max-w-xl rounded-[2.5rem] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="bg-slate-900 p-8 text-white relative">
              <button onClick={() => setIsCreatingAdmin(false)} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
              <div className="bg-blue-600 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                {editingAdminId ? <UserCog size={24} /> : <UserPlus size={24} />}
              </div>
              <h3 className="text-xl font-black">{editingAdminId ? 'Edit Profil Admin' : 'Tambah Admin Baru'}</h3>
              <p className="text-slate-400 text-xs mt-1">Konfigurasi akun, password, dan hak akses personil internal.</p>
            </div>
            
            <form onSubmit={handleSaveAdminUser} className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Username</label>
                  <div className="relative">
                    <UserCog className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required 
                      type="text"
                      placeholder="nama_pengguna"
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-6 focus:border-blue-600 outline-none transition-all font-bold" 
                      value={newAdminForm.username} 
                      onChange={e => setNewAdminForm({...newAdminForm, username: e.target.value.toLowerCase().replace(/\s/g, '_')})} 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required 
                      type="email"
                      placeholder="admin@ppti.or.id"
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-6 focus:border-blue-600 outline-none transition-all font-medium" 
                      value={newAdminForm.email} 
                      onChange={e => setNewAdminForm({...newAdminForm, email: e.target.value})} 
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Password Akun</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input 
                    required 
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-12 focus:border-blue-600 outline-none transition-all font-bold" 
                    value={newAdminForm.password} 
                    onChange={e => setNewAdminForm({...newAdminForm, password: e.target.value})} 
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-600 transition-colors"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Role Utama</label>
                <div className="relative">
                  <Shield className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <select 
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-10 focus:border-blue-600 outline-none transition-all font-bold appearance-none cursor-pointer"
                    value={newAdminForm.role}
                    onChange={e => handleRoleChange(e.target.value as any)}
                  >
                    <option value="Editor">Editor (Konten & Artikel)</option>
                    <option value="Super Admin">Super Admin (Kontrol Penuh)</option>
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={18} />
                </div>
                <p className="text-[10px] text-slate-400 italic ml-2">* Memilih role akan otomatis menyesuaikan daftar hak akses menu di bawah.</p>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <Key className="text-blue-600" size={18} />
                  <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Detail Hak Akses Menu</h4>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    { id: 'dashboard', label: 'Dashboard Ringkasan', icon: <LayoutDashboard size={14} /> },
                    { id: 'articles', label: 'Pengelolaan Artikel', icon: <FileText size={14} /> },
                    { id: 'members', label: 'Direktori Keanggotaan', icon: <Users size={14} /> },
                    { id: 'skills', label: 'Manajemen Keahlian', icon: <Tags size={14} /> },
                    { id: 'users', label: 'Manajemen Pengguna Admin', icon: <UserCog size={14} /> },
                  ].map((menu) => (
                    <label 
                      key={menu.id} 
                      className={`flex items-center gap-3 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        newAdminForm.permissions.includes(menu.id as TabType)
                          ? 'bg-blue-50 border-blue-200'
                          : 'bg-white border-slate-50 hover:border-slate-100'
                      }`}
                    >
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded text-blue-600"
                        checked={newAdminForm.permissions.includes(menu.id as TabType)}
                        onChange={() => togglePermission(menu.id as TabType)}
                      />
                      <div className="flex items-center gap-2">
                        <div className={`${newAdminForm.permissions.includes(menu.id as TabType) ? 'text-blue-600' : 'text-slate-400'}`}>
                          {menu.icon}
                        </div>
                        <span className={`text-xs font-bold ${newAdminForm.permissions.includes(menu.id as TabType) ? 'text-blue-700' : 'text-slate-500'}`}>
                          {menu.label}
                        </span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setIsCreatingAdmin(false)} className="flex-1 py-4 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl transition-all">Batal</button>
                <button 
                  type="submit" 
                  disabled={isSaving}
                  className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-black text-sm hover:bg-blue-700 shadow-xl shadow-blue-100 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  {isSaving ? <Loader2 className="animate-spin" size={18} /> : saveStatus === 'success' ? <CheckCircle2 size={18} /> : <Save size={18} />}
                  {isSaving ? 'Memproses...' : saveStatus === 'success' ? 'Berhasil!' : editingAdminId ? 'Perbarui Akses' : 'Daftarkan Admin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Edit Keahlian - Tetap sama */}
      {skillToEdit && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setSkillToEdit(null)}></div>
          <div className="relative bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in-95 duration-300">
            <h3 className="text-xl font-black text-slate-900 mb-2">Edit Nama Keahlian</h3>
            <p className="text-xs text-slate-500 mb-8 font-medium">Perubahan nama akan otomatis diperbarui di seluruh profil anggota.</p>
            
            <form onSubmit={handleUpdateSkill} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Nama Keahlian Baru</label>
                <input 
                  autoFocus
                  type="text" 
                  required 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all font-bold" 
                  value={skillToEdit.new} 
                  onChange={e => setSkillToEdit({...skillToEdit, new: e.target.value})} 
                />
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setSkillToEdit(null)} className="flex-1 py-4 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl transition-all">Batal</button>
                <button type="submit" className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-black text-sm hover:bg-blue-700 shadow-xl shadow-blue-100 active:scale-95 transition-all">
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Editor Modal for Articles - Tetap sama */}
      {editingArticle && (
        <div className="fixed inset-0 z-[60] flex items-center justify-end">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditingArticle(null)}></div>
          <div className="relative bg-white w-full max-w-4xl h-full shadow-2xl animate-in slide-in-from-right duration-500 overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-100 p-8 flex items-center justify-between z-10">
              <h3 className="text-2xl font-black text-slate-900">Editor Artikel</h3>
              <button onClick={() => setEditingArticle(null)} className="p-2 hover:bg-slate-50 rounded-xl"><X size={24} /></button>
            </div>
            <form onSubmit={handleSaveArticle} className="p-10 space-y-8 pb-32">
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Judul Artikel</label>
                <input type="text" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all font-bold" value={editingArticle.title} onChange={e => setEditingArticle({...editingArticle, title: e.target.value})} />
              </div>
              <div className="fixed bottom-0 left-0 right-0 p-8 bg-white/80 backdrop-blur-md border-t border-slate-100 flex justify-end gap-4 max-w-4xl ml-auto">
                <button type="button" onClick={() => setEditingArticle(null)} className="px-8 py-4 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl">Batal</button>
                <button disabled={isSaving} className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-blue-700">
                  {isSaving ? <Loader2 className="animate-spin" /> : <Save size={20} />} Simpan Artikel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Editor Modal for Members - Tetap sama */}
      {editingMember && (
        <div className="fixed inset-0 z-[60] flex items-center justify-end">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditingMember(null)}></div>
          <div className="relative bg-white w-full max-w-4xl h-full shadow-2xl animate-in slide-in-from-right duration-500 overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-100 p-8 flex items-center justify-between z-10">
              <div>
                <h3 className="text-2xl font-black text-slate-900">Editor Profil Anggota</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Update identitas profesional di direktori</p>
              </div>
              <button onClick={() => setEditingMember(null)} className="p-2 hover:bg-slate-50 rounded-xl text-slate-400"><X size={28} /></button>
            </div>

            <div className="p-10 space-y-12 pb-32">
              <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 flex flex-col md:flex-row items-center gap-8">
                 <div className="relative group shrink-0">
                    <div 
                      className="w-64 shadow-2xl rounded-2xl overflow-hidden border-2 border-white cursor-pointer group"
                      onClick={() => fileInputRef.current?.click()}
                    >
                        <img 
                          src={isCustomAvatar ? editingMember.avatar : getMembershipCard(editingMember.name, editingMember.id, editingMember.title)} 
                          alt="Preview Card" 
                          className="w-full h-auto"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-2xl">
                           <Camera className="text-white" size={32} />
                        </div>
                    </div>
                    <input 
                      ref={fileInputRef}
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleFileUpload} 
                    />
                 </div>
                 <div className="flex-1 space-y-4">
                    <div>
                      <h4 className="font-black text-slate-900 flex items-center gap-2">
                        <CreditCard className="text-blue-600" size={18} /> Media Profil & Kartu
                      </h4>
                      <p className="text-xs text-slate-500 leading-relaxed mt-1">Anda dapat menggunakan kartu otomatis sistem atau mengunggah file gambar kustom (PNG/JPG).</p>
                    </div>
                    
                    <div className="flex flex-wrap gap-3">
                       <button 
                         type="button" 
                         onClick={() => fileInputRef.current?.click()}
                         className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-all shadow-sm"
                       >
                         <Upload size={14} /> Unggah Foto/Kartu
                       </button>
                       {isCustomAvatar && (
                         <button 
                           type="button" 
                           onClick={handleResetAvatar}
                           className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-all border border-blue-100"
                         >
                           <RefreshCw size={14} /> Gunakan Kartu Otomatis
                         </button>
                       )}
                    </div>
                 </div>
              </div>

              <form onSubmit={handleSaveMember} className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">ID Anggota</label>
                    <input type="text" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all font-mono font-bold" value={editingMember.id} onChange={e => setEditingMember({...editingMember, id: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Nama Lengkap & Gelar</label>
                    <input type="text" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all font-bold" value={editingMember.name} onChange={e => setEditingMember({...editingMember, name: e.target.value})} />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Jabatan / Spesialisasi Utama</label>
                    <input type="text" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all font-bold text-blue-600" value={editingMember.title} onChange={e => setEditingMember({...editingMember, title: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Lokasi Domisili</label>
                    <input type="text" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all" value={editingMember.location} onChange={e => setEditingMember({...editingMember, location: e.target.value})} />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2 block">Pilih Keahlian Anggota</label>
                  <div className="flex flex-wrap gap-2 p-6 bg-slate-50 rounded-3xl border-2 border-slate-100">
                    {allSkills.map(skill => (
                      <button
                        key={skill}
                        type="button"
                        onClick={() => toggleMemberSkill(skill)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border-2 ${
                          editingMember.skills.includes(skill)
                            ? 'bg-blue-600 border-blue-600 text-white shadow-md'
                            : 'bg-white border-transparent text-slate-500 hover:border-blue-100'
                        }`}
                      >
                        {editingMember.skills.includes(skill) && <Check size={14} />}
                        {skill}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Biografi Singkat</label>
                  <textarea rows={4} required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 outline-none transition-all resize-none leading-relaxed" value={editingMember.bio} onChange={e => setEditingMember({...editingMember, bio: e.target.value})}></textarea>
                </div>

                <div className="fixed bottom-0 left-0 right-0 p-8 bg-white/80 backdrop-blur-md border-t border-slate-100 flex justify-end gap-4 max-w-4xl ml-auto">
                   <button type="button" onClick={() => setEditingMember(null)} className="px-8 py-4 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl transition-all">Batalkan</button>
                   <button disabled={isSaving} className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-blue-700 shadow-xl shadow-blue-100 active:scale-95 transition-all">
                     {isSaving ? <Loader2 className="animate-spin" /> : <Save size={20} />}
                     Simpan Data Anggota
                   </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
