
import React, { useState, useMemo, useEffect } from 'react';
import { ArrowLeft, ArrowUpRight, Tag, Search, Filter, FolderOpen, ChevronRight, Clock } from 'lucide-react';
import { articles, Article } from '../data/articles';

interface AllNewsProps {
  onArticleClick: (article: Article) => void;
  onBack: () => void;
}

const AllNews: React.FC<AllNewsProps> = ({ onArticleClick, onBack }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');

  // Ambil daftar kategori unik untuk filter tabs (Data sudah dinormalisasi di articles.tsx)
  const categories = useMemo(() => {
    const cats = ['Semua'];
    articles.forEach(a => {
      if (!cats.includes(a.category)) cats.push(a.category);
    });
    return cats;
  }, []);

  // Filter artikel berdasarkan pencarian dan kategori yang dipilih
  const filteredArticles = useMemo(() => {
    return articles.filter(a => {
      const matchesSearch = a.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          a.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'Semua' || a.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  // Kelompokkan artikel yang sudah difilter berdasarkan kategori
  const groupedArticles = useMemo(() => {
    const groups: Record<string, Article[]> = {};
    
    filteredArticles.forEach(article => {
      if (!groups[article.category]) {
        groups[article.category] = [];
      }
      groups[article.category].push(article);
    });
    
    return groups;
  }, [filteredArticles]);

  // Urutan kategori yang akan ditampilkan
  const categoryOrder = useMemo(() => {
    return Object.keys(groupedArticles).sort();
  }, [groupedArticles]);

  // Efek untuk memastikan konten yang difilter langsung muncul (bypass scroll reveal opacity 0)
  useEffect(() => {
    const timer = setTimeout(() => {
      const revealElements = document.querySelectorAll('.filter-item');
      revealElements.forEach(el => el.classList.add('revealed'));
    }, 50);
    return () => clearTimeout(timer);
  }, [filteredArticles, selectedCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24 animate-in fade-in duration-500">
      {/* Header Section */}
      <div className="mb-12">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-6 transition-colors group"
        >
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          Kembali ke Beranda
        </button>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Daftar Berita & Wawasan</h2>
            <p className="text-slate-500 mt-2">Arsip lengkap inisiatif dan publikasi profesional PPTI Indonesia.</p>
          </div>
          <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-2xl border border-blue-100">
            <FolderOpen className="text-blue-600" size={18} />
            <span className="text-xs font-black text-blue-700 uppercase tracking-widest">
              {Object.keys(groupedArticles).length} Kelompok Kategori
            </span>
          </div>
        </div>
      </div>

      {/* Filters & Search Control Panel */}
      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 mb-16 flex flex-col lg:flex-row gap-6 items-center sticky top-24 z-30">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text"
            placeholder="Cari berita atau wawasan..."
            className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:border-blue-600 focus:outline-none transition-all text-sm font-medium"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-3 w-full lg:w-auto overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
          <Filter size={18} className="text-slate-400 shrink-0" />
          <div className="flex gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-3 rounded-xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
                  selectedCategory === cat 
                    ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-200' 
                    : 'bg-white border-slate-100 text-slate-500 hover:border-blue-200 hover:text-blue-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grouped Content */}
      {categoryOrder.length > 0 ? (
        <div className="space-y-20">
          {categoryOrder.map((category) => (
            <section key={category} className="filter-item reveal reveal-up">
              {/* Category Header Section */}
              <div className="flex items-center gap-4 mb-8">
                <div className="bg-blue-600 p-3 rounded-2xl text-white shadow-lg shadow-blue-100">
                  <Tag size={20} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Kategori: {category}</h3>
                  <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.2em] mt-1">
                    {groupedArticles[category].length} Artikel Tersedia
                  </p>
                </div>
                <div className="flex-1 h-px bg-slate-100 ml-4 hidden md:block"></div>
              </div>

              {/* Grid for this category */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {groupedArticles[category].map((item, idx) => (
                  <div 
                    key={item.id} 
                    className="group bg-white rounded-[2.5rem] overflow-hidden shadow-sm border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 flex flex-col filter-item reveal reveal-up"
                    style={{ transitionDelay: `${idx * 50}ms` }}
                  >
                    <div className={`h-48 relative overflow-hidden ${item.isGraphic ? 'bg-slate-50 p-6' : 'bg-slate-100'}`}>
                      <img 
                        src={item.image} 
                        alt={item.title} 
                        className={`w-full h-full transition-transform duration-700 group-hover:scale-110 ${item.isGraphic ? 'object-contain' : 'object-cover'}`} 
                        loading="lazy"
                      />
                      {!item.isGraphic && <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>}
                      <div className="absolute top-4 right-4">
                         <div className="bg-white/90 backdrop-blur-sm p-2 rounded-xl text-blue-600 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                            <ArrowUpRight size={18} />
                         </div>
                      </div>
                    </div>
                    
                    <div className="p-8 flex flex-col flex-1 justify-between">
                      <div>
                        <div className="bg-blue-50 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors">
                          <div className="group-hover:text-white transition-colors">
                            {item.icon}
                          </div>
                        </div>
                        <h4 className="text-xl font-black text-slate-900 mb-4 leading-tight group-hover:text-blue-600 transition-colors line-clamp-2">
                          {item.title}
                        </h4>
                        <p className="text-slate-500 text-sm leading-relaxed mb-6 line-clamp-3">
                          {item.description}
                        </p>
                      </div>
                      
                      <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1">
                            <Tag size={10} className="text-blue-400" /> {item.category}
                          </span>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                            <Clock size={10} /> 24 Mei 2024
                          </span>
                        </div>
                        <button 
                          onClick={() => onArticleClick(item)}
                          className="bg-slate-900 text-white px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 hover:bg-blue-600 transition-all active:scale-95"
                        >
                          Detail Artikel <ChevronRight size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="py-32 text-center bg-white rounded-[4rem] border-2 border-dashed border-slate-200 animate-in zoom-in-95 duration-500">
          <div className="bg-slate-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
             <Search size={48} strokeWidth={1} />
          </div>
          <h4 className="text-2xl font-black text-slate-900 mb-2">Berita Tidak Ditemukan</h4>
          <p className="text-slate-500 font-medium max-w-sm mx-auto">Tidak ada hasil yang cocok dengan kata kunci "{searchQuery}" di kategori "{selectedCategory}".</p>
          <button 
            onClick={() => {setSearchQuery(''); setSelectedCategory('Semua');}}
            className="mt-8 bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all active:scale-95"
          >
            Bersihkan Semua Filter
          </button>
        </div>
      )}

      {/* Quick Access Floating Info */}
      <div className="mt-24 p-10 bg-gradient-to-br from-slate-900 to-blue-900 rounded-[3rem] text-white flex flex-col md:flex-row items-center justify-between gap-8 filter-item revealed">
        <div className="flex items-center gap-6">
          <div className="bg-white/10 p-5 rounded-[1.5rem] border border-white/10">
            <FolderOpen size={32} className="text-blue-400" />
          </div>
          <div>
            <h5 className="text-2xl font-bold">Butuh Informasi Spesifik?</h5>
            <p className="text-blue-100/70 text-sm max-w-md mt-1">Gunakan fitur pencarian dan filter kategori di atas untuk menemukan arsip program PPTI dengan cepat.</p>
          </div>
        </div>
        <button 
          onClick={onBack}
          className="bg-white text-slate-900 px-10 py-4 rounded-2xl font-bold hover:bg-blue-50 transition-all shadow-xl shadow-slate-950/20 whitespace-nowrap"
        >
          Kembali ke Beranda
        </button>
      </div>
    </div>
  );
};

export default AllNews;
