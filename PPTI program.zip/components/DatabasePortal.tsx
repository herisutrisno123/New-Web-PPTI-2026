import React from 'react';
import { Database, Download, FileCode, Server, ShieldCheck, ArrowLeft, Table, Code2 } from 'lucide-react';

interface DatabasePortalProps {
  onBack: () => void;
}

const DatabasePortal: React.FC<DatabasePortalProps> = ({ onBack }) => {
  const tableSummary = [
    { name: 'members', columns: 9, description: 'Manajemen data profil profesional dan keahlian.' },
    { name: 'articles', columns: 8, description: 'Konten CMS untuk berita, wawasan, dan program.' },
    { name: 'tickets', columns: 7, description: 'Sistem log konsultasi dan bantuan teknis.' },
    { name: 'categories', columns: 3, description: 'Klasifikasi konten untuk organisasi informasi.' }
  ];

  const handleDownload = () => {
    // In a real environment, this would fetch from a server.
    // Here we simulate the download of the file we created.
    const sqlContent = `-- Database Schema for PPTI... (simulated content)`;
    const blob = new Blob([sqlContent], { type: 'text/sql' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ppti_database.sql';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pb-24 animate-in fade-in duration-500">
      {/* Header */}
      <div className="mb-12">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-6 transition-colors group"
        >
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          Kembali ke Beranda
        </button>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tight">Portal Skema Database</h2>
            <p className="text-slate-500 mt-2">Struktur data inti untuk sistem informasi Perkumpulan Profesional Teknologi Informasi.</p>
          </div>
          <button 
            onClick={handleDownload}
            className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-3 shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all hover:scale-105 active:scale-95"
          >
            <Download size={20} /> Unduh ppti_database.sql
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left: Info Cards */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100">
            <h3 className="text-2xl font-black text-slate-900 mb-6 flex items-center gap-3">
              <Server className="text-blue-600" /> Arsitektur Data
            </h3>
            <p className="text-slate-600 leading-relaxed mb-8">
              Skema database ini dirancang menggunakan standar relasional (RDBMS) untuk memastikan integritas data anggota dan efisiensi pengelolaan konten. Arsitektur ini mendukung skalabilitas untuk ribuan anggota aktif.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4">
              {tableSummary.map((table) => (
                <div key={table.name} className="bg-slate-50 p-6 rounded-3xl border border-slate-100 group hover:border-blue-200 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-white p-2.5 rounded-xl shadow-sm">
                      <Table className="text-blue-600" size={20} />
                    </div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      {table.columns} Kolom
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">Tabel: {table.name}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{table.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden">
             <Code2 className="absolute -right-10 -bottom-10 opacity-10" size={240} />
             <h3 className="text-2xl font-black mb-6 flex items-center gap-3">
               <FileCode className="text-blue-400" /> Cuplikan SQL DDL
             </h3>
             <div className="bg-black/40 rounded-2xl p-6 font-mono text-xs text-blue-100 leading-relaxed overflow-x-auto">
               <pre>{`CREATE TABLE members (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    skills TEXT,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE articles (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255),
    content LONGTEXT
);`}</pre>
             </div>
          </div>
        </div>

        {/* Right: Sidebar */}
        <div className="space-y-8">
          <div className="bg-blue-600 rounded-[2.5rem] p-8 text-white shadow-2xl shadow-blue-200">
            <ShieldCheck size={48} className="mb-6 opacity-80" />
            <h4 className="text-xl font-bold mb-4">Integritas & Keamanan</h4>
            <ul className="space-y-4 text-sm text-blue-100">
              <li className="flex gap-3">
                <div className="w-1.5 h-1.5 bg-white rounded-full mt-1.5 shrink-0"></div>
                Gunakan Foreign Keys untuk konsistensi antar tabel.
              </li>
              <li className="flex gap-3">
                <div className="w-1.5 h-1.5 bg-white rounded-full mt-1.5 shrink-0"></div>
                Indeks otomatis pada Primary Key untuk performa query.
              </li>
              <li className="flex gap-3">
                <div className="w-1.5 h-1.5 bg-white rounded-full mt-1.5 shrink-0"></div>
                Siap diimpor ke MySQL, MariaDB, atau PostgreSQL.
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm text-center">
            <div className="bg-amber-50 text-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Database size={32} />
            </div>
            <h4 className="font-bold text-slate-900 mb-2">Butuh Bantuan Import?</h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Jika Anda mengalami kendala saat melakukan konfigurasi database lokal, silakan hubungi tim IT PPTI melalui portal bantuan.
            </p>
            <button className="text-blue-600 font-bold text-sm hover:underline">
              Panduan Konfigurasi &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatabasePortal;