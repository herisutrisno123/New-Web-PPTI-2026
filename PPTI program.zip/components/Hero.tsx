
import React, { useState, useEffect } from 'react';
import { Shield, Users, ChevronRight, Award, ArrowRight } from 'lucide-react';

interface HeroProps {
  onAboutClick?: () => void;
  onRegisterClick?: (type: 'umum' | 'perusahaan') => void;
}

const Hero: React.FC<HeroProps> = ({ onAboutClick, onRegisterClick }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      url: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=1200",
      alt: "Profesional TI bekerja di kantor modern"
    },
    {
      url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=1200",
      alt: "Kolaborasi tim pengembang perangkat lunak"
    },
    {
      url: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1200",
      alt: "Infrastruktur teknologi informasi canggih"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="hero" className="relative pt-24 pb-10 lg:pt-36 lg:pb-14 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 -z-10 w-1/2 h-1/2 bg-blue-50 rounded-full blur-3xl opacity-50 translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 left-0 -z-10 w-1/3 h-1/3 bg-cyan-50 rounded-full blur-3xl opacity-50 -translate-x-1/2 translate-y-1/2"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="reveal reveal-right space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 bg-blue-600/10 text-blue-700 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest border border-blue-200 shadow-sm animate-pulse">
                <Award size={14} /> Berdiri Sejak 1 Juni 2018
              </div>
              <h1 className="text-5xl lg:text-7xl font-black text-slate-900 leading-[1.1] tracking-tight">
                Membangun <span className="text-blue-600">Profesionalisme</span> TI Indonesia
              </h1>
              <p className="mt-6 text-xl text-slate-600 leading-relaxed max-w-2xl font-medium">
                PPTI adalah <span className="text-slate-900 font-bold">organisasi keprofesian</span> di bidang Teknologi Informasi yang mandiri dan non-profit, berdedikasi meningkatkan kedaulatan digital nasional.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onRegisterClick && onRegisterClick('umum')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-black text-lg transition-all shadow-xl shadow-blue-200 hover:scale-105 active:scale-95 flex items-center gap-2 group"
              >
                Gabung Sekarang <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={onAboutClick}
                className="bg-white border-2 border-slate-200 hover:border-blue-600 text-slate-700 hover:text-blue-600 px-10 py-4 rounded-2xl font-black text-lg transition-all hover:bg-blue-50 active:scale-95 hover:scale-105 flex items-center gap-2 group"
              >
                Profil Organisasi <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          <div className="relative reveal reveal-left delay-200">
            {/* Main Slider Display */}
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,56,168,0.2)] aspect-[4/3] bg-slate-200 border-8 border-white">
              {slides.map((slide, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                    index === currentSlide ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  <img 
                    src={slide.url} 
                    alt={slide.alt} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent"></div>
                </div>
              ))}
              
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-30">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-2.5 rounded-full transition-all duration-500 ${
                      index === currentSlide ? 'w-10 bg-white shadow-lg' : 'w-2.5 bg-white/40 hover:bg-white/70'
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* Floating Badges for Home Context */}
            <div className="absolute -bottom-10 -left-10 bg-white p-6 rounded-3xl shadow-2xl z-20 hidden sm:flex items-center gap-5 reveal reveal-up delay-500 border border-slate-50">
              <div className="bg-green-100 p-3 rounded-2xl text-green-600">
                <Shield size={32} />
              </div>
              <div>
                <div className="text-lg font-black text-slate-900 leading-none">Mandiri</div>
                <div className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Non-Profit Organization</div>
              </div>
            </div>
            
            <div className="absolute -top-10 -right-10 bg-blue-600 p-6 rounded-3xl shadow-2xl z-20 hidden sm:flex items-center gap-5 reveal reveal-down delay-700 border-4 border-white">
              <div className="bg-white/20 p-3 rounded-2xl text-white">
                <Users size={32} />
              </div>
              <div className="text-white">
                <div className="text-lg font-black leading-none">Keprofesian</div>
                <div className="text-xs text-blue-100 font-bold uppercase tracking-widest mt-1">Jaringan Nasional</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
