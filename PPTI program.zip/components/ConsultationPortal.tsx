
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MessageSquare, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  Plus, 
  FileText,
  User,
  ShieldCheck,
  History,
  Calendar,
  MoreVertical
} from 'lucide-react';

interface Ticket {
  id: string;
  subject: string;
  category: string;
  status: 'Open' | 'In Progress' | 'Closed';
  date: string;
  lastUpdate: string;
  description: string;
  messages: {
    role: 'user' | 'admin';
    text: string;
    timestamp: string;
  }[];
}

interface ConsultationPortalProps {
  onBack: () => void;
}

const ConsultationPortal: React.FC<ConsultationPortalProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newMessage, setNewMessage] = useState('');

  // Dummy Tickets Data
  const [tickets, setTickets] = useState<Ticket[]>([
    {
      id: "TKT-2024-001",
      subject: "Implementasi DMM-CaaS untuk BUMD",
      category: "Maturity Assessment",
      status: "In Progress",
      date: "20 Mei 2024",
      lastUpdate: "2 jam yang lalu",
      description: "Kami membutuhkan panduan awal untuk penerapan asesmen manajemen data di lingkungan BUMD Jawa Barat.",
      messages: [
        { role: 'user', text: "Selamat siang pengurus PPTI, kami tertarik dengan layanan DMM-CaaS. Apa saja syarat awalnya?", timestamp: "20 Mei 2024 10:00" },
        { role: 'admin', text: "Selamat siang. Untuk tahap awal, kami perlu profil organisasi dan jumlah dataset utama yang ingin dikelola. Tim asesor kami akan mengirimkan kuesioner awal.", timestamp: "20 Mei 2024 14:30" }
      ]
    },
    {
      id: "TKT-2024-002",
      subject: "Sertifikasi Kompetensi Digital Tim IT",
      category: "Pengembangan SDM",
      status: "Open",
      date: "23 Mei 2024",
      lastUpdate: "Baru saja",
      description: "Ingin menanyakan biaya paket korporasi untuk asesmen kompetensi 50 orang staf IT.",
      messages: []
    },
    {
      id: "TKT-2023-088",
      subject: "Audit Keamanan Sistem Kawasan",
      category: "Inisiatif Strategis",
      status: "Closed",
      date: "10 Des 2023",
      lastUpdate: "15 Des 2023",
      description: "Permintaan audit untuk kawasan pilot project KSB di Sumatera Utara.",
      messages: [
        { role: 'user', text: "Mohon bantuan audit keamanan.", timestamp: "10 Des 2023" },
        { role: 'admin', text: "Audit telah selesai. Laporan telah dikirim ke email terdaftar.", timestamp: "15 Des 2023" }
      ]
    }
  ]);

  const activeTickets = tickets.filter(t => t.status !== 'Closed');
  const historyTickets = tickets.filter(t => t.status === 'Closed');

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedTicket) return;
    
    const updatedTickets = tickets.map(t => {
      if (t.id === selectedTicket.id) {
        return {
          ...t,
          lastUpdate: "Baru saja",
          messages: [...t.messages, {
            role: 'user' as const,
            text: newMessage,
            timestamp: new Date().toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
          }]
        };
      }
      return t;
    });

    setTickets(updatedTickets);
    setSelectedTicket(updatedTickets.find(t => t.id === selectedTicket.id) || null);
    setNewMessage('');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pb-20 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
        <div>
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold mb-4 transition-colors group"
          >
            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            Kembali ke Beranda
          </button>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Portal Konsultasi Program</h2>
          <p className="text-slate-500 mt-2">Diskusikan kebutuhan teknologi Anda langsung dengan pakar PPTI.</p>
        </div>
        
        {!selectedTicket && !isCreating && (
          <button 
            onClick={() => setIsCreating(true)}
            className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all hover:scale-105 active:scale-95"
          >
            <Plus size={20} /> Mulai Konsultasi Baru
          </button>
        )}
      </div>

      {selectedTicket ? (
        <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100 flex flex-col md:flex-row h-[700px] animate-in zoom-in-95 duration-300">
          {/* Ticket Sidebar Info */}
          <div className="md:w-1/3 bg-slate-900 p-10 text-white flex flex-col justify-between">
            <div className="space-y-8">
              <button 
                onClick={() => setSelectedTicket(null)}
                className="text-slate-400 hover:text-white flex items-center gap-2 text-sm font-bold transition-colors"
              >
                <ArrowLeft size={16} /> Tutup Tiket
              </button>
              
              <div>
                <div className="inline-block px-3 py-1 bg-blue-600 rounded-lg text-[10px] font-black uppercase tracking-widest mb-3">
                  {selectedTicket.category}
                </div>
                <h3 className="text-2xl font-black leading-tight mb-4">{selectedTicket.subject}</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-slate-400">
                    <Clock size={16} />
                    <span className="text-xs font-bold">Tiket ID: {selectedTicket.id}</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-400">
                    <Calendar size={16} />
                    <span className="text-xs font-bold">Dibuat: {selectedTicket.date}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {selectedTicket.status === 'Open' ? (
                      <AlertCircle size={16} className="text-amber-400" />
                    ) : (
                      <CheckCircle2 size={16} className="text-green-400" />
                    )}
                    <span className={`text-xs font-black uppercase tracking-widest ${selectedTicket.status === 'Open' ? 'text-amber-400' : 'text-green-400'}`}>
                      {selectedTicket.status}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-white/10">
                <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-4">Deskripsi Masalah:</p>
                <p className="text-sm text-slate-300 leading-relaxed italic">
                  "{selectedTicket.description}"
                </p>
              </div>
            </div>

            <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
               <div className="flex items-center gap-3 mb-2">
                 <ShieldCheck className="text-blue-400" size={18} />
                 <span className="text-xs font-bold">Jaminan Keamanan</span>
               </div>
               <p className="text-[10px] text-slate-500 leading-relaxed italic">
                 Seluruh diskusi ini bersifat rahasia dan hanya dapat diakses oleh Anda dan pengurus resmi PPTI.
               </p>
            </div>
          </div>

          {/* Chat Interface */}
          <div className="md:w-2/3 flex flex-col bg-slate-50">
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
               {selectedTicket.messages.length === 0 ? (
                 <div className="h-full flex flex-col items-center justify-center text-center py-20">
                   <div className="bg-white p-6 rounded-full shadow-lg mb-6 text-slate-300">
                     <MessageSquare size={64} strokeWidth={1} />
                   </div>
                   <h4 className="text-xl font-black text-slate-900 mb-2">Belum ada diskusi</h4>
                   <p className="text-slate-500 max-w-xs mx-auto">Tulis pesan pertama Anda untuk memulai diskusi dengan Pengurus PPTI.</p>
                 </div>
               ) : (
                 selectedTicket.messages.map((msg, idx) => (
                   <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                     <div className={`max-w-[80%] flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`flex items-center gap-2 mb-1.5 px-2`}>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            {msg.role === 'user' ? 'Anda' : 'Admin PPTI'}
                          </span>
                          <span className="text-[9px] text-slate-300">•</span>
                          <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                        </div>
                        <div className={`p-4 rounded-3xl shadow-sm text-sm leading-relaxed ${
                          msg.role === 'user' 
                            ? 'bg-blue-600 text-white rounded-tr-none' 
                            : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'
                        }`}>
                          {msg.text}
                        </div>
                     </div>
                   </div>
                 ))
               )}
            </div>

            {/* Input Area */}
            {selectedTicket.status !== 'Closed' && (
              <div className="p-8 bg-white border-t border-slate-200">
                <div className="flex gap-4">
                  <div className="flex-1 relative">
                    <textarea 
                      rows={2}
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                      placeholder="Ketik pesan konsultasi Anda di sini..."
                      className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all text-sm resize-none"
                    ></textarea>
                  </div>
                  <button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="bg-blue-600 text-white px-6 rounded-2xl font-bold flex items-center justify-center hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 disabled:opacity-50 disabled:shadow-none"
                  >
                    <Send size={24} />
                  </button>
                </div>
                <div className="mt-3 flex items-center gap-2 text-[10px] text-slate-400 font-medium">
                  <Clock size={12} /> Rata-rata waktu tanggapan: 4-6 jam kerja.
                </div>
              </div>
            )}
          </div>
        </div>
      ) : isCreating ? (
        <div className="bg-white rounded-[3rem] shadow-2xl p-10 lg:p-14 border border-slate-100 animate-in zoom-in-95 duration-300">
           <div className="max-w-2xl mx-auto space-y-10">
              <div className="text-center">
                <div className="bg-blue-50 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 text-blue-600">
                  <Plus size={40} />
                </div>
                <h3 className="text-3xl font-black text-slate-900">Mulai Diskusi Baru</h3>
                <p className="text-slate-500 mt-2">Lengkapi detail berikut agar pengurus dapat memberikan solusi yang tepat.</p>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Kategori Konsultasi</label>
                  <select className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all font-bold text-slate-700">
                    <option>Maturity Assessment (DMM/CaaS)</option>
                    <option>Pengembangan SDM & Sertifikasi</option>
                    <option>Inisiatif Strategis Kawasan (KSB)</option>
                    <option>Kemitraan & Kolaborasi</option>
                    <option>Lainnya</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Subjek Konsultasi</label>
                  <input 
                    type="text" 
                    placeholder="Contoh: Implementasi IoT di Sektor Pertanian"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all font-medium"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Detail Kebutuhan</label>
                  <textarea 
                    rows={5}
                    placeholder="Jelaskan tantangan atau kebutuhan organisasi Anda secara mendetail..."
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 focus:border-blue-600 focus:outline-none transition-all resize-none"
                  ></textarea>
                </div>
              </div>

              <div className="flex gap-4 pt-6">
                <button 
                  onClick={() => setIsCreating(false)}
                  className="flex-1 border-2 border-slate-100 py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50 transition-all"
                >
                  Batalkan
                </button>
                <button 
                  onClick={() => {
                    // Simulasikan pembuatan tiket sukses
                    setIsCreating(false);
                    setSelectedTicket(tickets[1]); // Pilih tiket dummy kedua
                  }}
                  className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all"
                >
                  Kirim Permintaan Konsultasi
                </button>
              </div>
           </div>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Tab Filter */}
          <div className="flex p-1.5 bg-slate-200/50 rounded-2xl w-fit">
            <button 
              onClick={() => setActiveTab('active')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'active' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <History size={18} /> Diskusi Aktif ({activeTickets.length})
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'history' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <FileText size={18} /> Riwayat Selesai ({historyTickets.length})
            </button>
          </div>

          {/* Ticket Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {(activeTab === 'active' ? activeTickets : historyTickets).map((ticket, idx) => (
              <div 
                key={ticket.id}
                onClick={() => setSelectedTicket(ticket)}
                className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-100 hover:shadow-2xl transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      ticket.status === 'Open' ? 'bg-amber-50 text-amber-600' : 
                      ticket.status === 'In Progress' ? 'bg-blue-50 text-blue-600' : 
                      'bg-slate-100 text-slate-400'
                    }`}>
                      {ticket.status}
                    </div>
                    <button className="text-slate-300 hover:text-slate-600">
                      <MoreVertical size={18} />
                    </button>
                  </div>
                  
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{ticket.category}</div>
                  <h4 className="text-xl font-black text-slate-900 group-hover:text-blue-600 transition-colors mb-4 line-clamp-2 leading-tight">
                    {ticket.subject}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed mb-6 line-clamp-2 italic">
                    "{ticket.description}"
                  </p>
                </div>

                <div className="pt-6 border-t border-slate-50 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                      <Clock size={14} /> Update: {ticket.lastUpdate}
                    </div>
                    <div className="flex -space-x-2">
                       <div className="w-7 h-7 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-blue-600">A</div>
                       <div className="w-7 h-7 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center text-slate-300">
                         <User size={14} />
                       </div>
                    </div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold text-slate-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    Lihat Percakapan <MessageSquare size={14} />
                  </div>
                </div>
              </div>
            ))}

            {activeTab === 'active' && activeTickets.length === 0 && (
              <div className="col-span-full py-20 text-center bg-white rounded-[3rem] border-2 border-dashed border-slate-200">
                <div className="text-slate-300 mb-4 flex justify-center"><History size={64} strokeWidth={1} /></div>
                <h4 className="text-2xl font-black text-slate-900">Belum ada diskusi aktif</h4>
                <p className="text-slate-500 max-w-sm mx-auto mt-2">Anda belum memiliki konsultasi yang sedang berjalan saat ini.</p>
                <button 
                  onClick={() => setIsCreating(true)}
                  className="mt-8 bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all"
                >
                  Mulai Konsultasi Pertama
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FAQs or Info */}
      {!selectedTicket && !isCreating && (
        <div className="mt-24 grid md:grid-cols-3 gap-8 reveal reveal-up delay-400">
           <div className="flex gap-4">
              <div className="bg-blue-100 p-3 rounded-2xl text-blue-600 h-12 w-12 flex items-center justify-center shrink-0">
                <AlertCircle size={24} />
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-1">Tanggapan Cepat</h5>
                <p className="text-xs text-slate-500 leading-relaxed">Pengurus PPTI berkomitmen menanggapi setiap tiket dalam waktu kurang dari 24 jam kerja.</p>
              </div>
           </div>
           <div className="flex gap-4">
              <div className="bg-blue-100 p-3 rounded-2xl text-blue-600 h-12 w-12 flex items-center justify-center shrink-0">
                <ShieldCheck size={24} />
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-1">Privasi Terjamin</h5>
                <p className="text-xs text-slate-500 leading-relaxed">Seluruh data teknis dan diskusi organisasi yang dibagikan dilindungi oleh kebijakan kerahasiaan PPTI.</p>
              </div>
           </div>
           <div className="flex gap-4">
              <div className="bg-blue-100 p-3 rounded-2xl text-blue-600 h-12 w-12 flex items-center justify-center shrink-0">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-1">Asisten Ahli</h5>
                <p className="text-xs text-slate-500 leading-relaxed">Anda akan dihubungkan dengan asesor atau pengurus yang paling kompeten di bidang konsultasi Anda.</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default ConsultationPortal;
