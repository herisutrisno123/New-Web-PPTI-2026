
import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin, LogIn } from 'lucide-react';

interface FooterProps {
  onContactClick?: () => void;
  onNavClick?: (href: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onContactClick, onNavClick }) => {
  const handleLinkClick = (e: React.MouseEvent, href: string) => {
    if (href === '#kontak') {
      e.preventDefault();
      onContactClick?.();
    } else if (onNavClick && href.startsWith('#')) {
      e.preventDefault();
      onNavClick(href);
    }
  };

  return (
    <footer id="kontak" className="bg-slate-900 text-slate-300 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-8">
            <div className="flex items-center">
              {/* Logo & Brand - Kembali ke Desain Teks */}
              <div className="flex items-center group cursor-pointer" onClick={(e) => handleLinkClick(e, '#hero')}>
                <div className="bg-blue-600 p-2 rounded-xl text-white shadow-lg group-hover:rotate-12 transition-transform">
                  <LogIn size={24} />
                </div>
                <div className="ml-3 text-left">
                  <span className="block font-black text-xl leading-none tracking-tighter text-white">PPTI</span>
                  <span className="block text-[8px] font-black uppercase tracking-[0.3em] text-blue-400">Profesional TI</span>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="text-white font-black text-lg tracking-tight">PPTI Pusat</h4>
              <p className="text-sm leading-relaxed opacity-80 max-w-xs">
                Perkumpulan Profesional Teknologi Informasi (PPTI) adalah organisasi keprofesian mandiri dan non-profit yang didirikan di Jakarta pada 1 Juni 2018.
              </p>
            </div>
            <div className="flex gap-4">
              <a href="#" className="bg-slate-800 p-2.5 rounded-xl hover:text-blue-400 hover:bg-slate-700 transition-all shadow-sm"><Facebook size={20} /></a>
              <a href="#" className="bg-slate-800 p-2.5 rounded-xl hover:text-blue-400 hover:bg-slate-700 transition-all shadow-sm"><Twitter size={20} /></a>
              <a href="#" className="bg-slate-800 p-2.5 rounded-xl hover:text-blue-400 hover:bg-slate-700 transition-all shadow-sm"><Linkedin size={20} /></a>
              <a href="#" className="bg-slate-800 p-2.5 rounded-xl hover:text-blue-400 hover:bg-slate-700 transition-all shadow-sm"><Instagram size={20} /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2">
              <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
              Tautan Cepat
            </h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#about" onClick={(e) => handleLinkClick(e, '#about')} className="hover:text-blue-400 transition-colors font-medium">Tentang Kami</a></li>
              <li><a href="#membership" onClick={(e) => handleLinkClick(e, '#membership')} className="hover:text-blue-400 transition-colors font-medium">Anggota PPTI</a></li>
              <li><a href="#all-news" onClick={(e) => handleLinkClick(e, '#all-news')} className="hover:text-blue-400 transition-colors font-medium">Berita Terbaru</a></li>
              <li><a href="#privacy-policy" onClick={(e) => handleLinkClick(e, '#privacy-policy')} className="hover:text-blue-400 transition-colors font-medium">Kebijakan Privasi</a></li>
              <li><a href="#kontak" onClick={(e) => handleLinkClick(e, '#kontak')} className="hover:text-blue-400 transition-colors font-bold text-blue-400">Hubungi Kami</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2">
              <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
              Informasi Kontak
            </h4>
            <ul className="space-y-5 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="text-blue-500 shrink-0 mt-1" size={18} />
                <span className="opacity-80 leading-relaxed font-medium">Jakarta Selatan, DKI Jakarta, Indonesia</span>
              </li>
              <li className="flex items-center gap-3 cursor-pointer hover:text-blue-400 transition-colors group" onClick={() => onContactClick?.()}>
                <div className="bg-slate-800 p-2 rounded-lg group-hover:bg-blue-600 transition-colors">
                  <Phone className="text-blue-500 group-hover:text-white" size={16} />
                </div>
                <span className="opacity-80 font-medium">+62 21 1234 5678</span>
              </li>
              <li className="flex items-center gap-3 cursor-pointer hover:text-blue-400 transition-colors group" onClick={() => onContactClick?.()}>
                <div className="bg-slate-800 p-2 rounded-lg group-hover:bg-blue-600 transition-colors">
                  <Mail className="text-blue-500 group-hover:text-white" size={16} />
                </div>
                <span className="opacity-80 font-medium">info@ppti.or.id</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2">
              <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
              Buletin PPTI
            </h4>
            <p className="text-sm mb-6 opacity-80 leading-relaxed font-medium">Dapatkan info tren TI terbaru langsung di inbox Anda.</p>
            <div className="flex flex-col gap-3">
              <input 
                type="email" 
                placeholder="Email Anda" 
                className="bg-slate-800 border-2 border-slate-700 rounded-xl px-4 py-3 text-sm w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
              />
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl text-sm font-bold transition-all shadow-lg shadow-blue-900/20 active:scale-95">
                Daftar Sekarang
              </button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] opacity-60 font-bold uppercase tracking-[0.1em]">
          <p>© 2018-{new Date().getFullYear()} PPTI - Perkumpulan Profesional Teknologi Informasi.</p>
          <div className="flex gap-6">
            <span className="text-blue-400">Kemenkumham RI: AHU-0007328.AH.01.07.Tahun 2018</span>
            <span>Membangun Masa Depan TI Indonesia.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
