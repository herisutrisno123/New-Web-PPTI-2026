import React, { useState } from 'react';
import { 
  Award, 
  Building2, 
  UserCircle, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  Percent,
  Megaphone,
  Briefcase,
  Info
} from 'lucide-react';

interface MembershipBenefitsProps {
  onRegister: (type: 'umum' | 'perusahaan') => void;
}

const MembershipBenefits: React.FC<MembershipBenefitsProps> = ({ onRegister }) => {
  const [activeTab, setActiveTab] = useState<'perusahaan' | 'umum' | 'kehormatan'>('perusahaan');

  const corporateTiers = [
    {
      name: 'Platinum',
      price: 'Rp 1.500.000',
      period: '/ tahun',
      color: 'bg-slate-900',
      textColor: 'text-white',
      accent: 'text-blue-400',
      benefits: [
        'Mendapatkan Sertifikat anggota Platinum PPTI',
        'Iklan produk di web PPTI tiap halaman (maks. 6 iklan/produk)',
        'Diskon 15% Pelatihan & Uji Sertifikasi di TUK Digital Business Indonesia (LSP KI)',
        'Diskon 15% Sponsor kegiatan SmartCity Maturity (CaaS PPTI)'
      ]
    },
    {
      name: 'Gold',
      price: 'Rp 1.000.000',
      period: '/ tahun',
      color: 'bg-amber-500',
      textColor: 'text-white',
      accent: 'text-amber-100',
      benefits: [
        'Mendapatkan Sertifikat anggota Gold PPTI',
        'Iklan produk di web PPTI tiap halaman (maks. 3 iklan/produk)',
        'Diskon 10% Pelatihan & Uji Sertifikasi di TUK Digital Business Indonesia (LSP KI)',
        'Diskon 10% Sponsor kegiatan SmartCity Maturity (CaaS PPTI)'
      ]
    },
    {
      name: 'Silver',
      price: 'Rp 500.000',
      period: '/ tahun',
      color: 'bg-slate-300',
      textColor: 'text-slate-800',
      accent: 'text-blue-700',
      benefits: [
        'Mendapatkan Sertifikat anggota Silver PPTI',
        'Iklan produk di web PPTI tiap halaman (maks. 1 iklan/produk)',
        'Diskon 5% Pelatihan & Uji Sertifikasi di TUK Digital Business Indonesia (LSP KI)',
        'Diskon 5% Sponsor kegiatan SmartCity Maturity (CaaS PPTI)'
      ]
    }
  ];

  return (
    <section id="membership" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-40 -mr-48 -mt-48"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-slate-100 rounded-full blur-3xl opacity-60 -ml-32 -mb-32"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 reveal reveal-up">
          <h2 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-4">Keanggotaan PPTI (CONTOH)</h2>
          <h3 className="text-4xl font-extrabold text-slate-900 sm:text-5xl mb-6 tracking-tight">Menjadi Anggota PPTI</h3>
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 max-w-3xl mx-auto inline-flex items-center gap-4 text-left">
            <div className="bg-blue-600 text-white p-2 rounded-xl shrink-0">
              <Info size={20} />
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">
              Anggota PPTI adalah perorangan atau perusahaan yang menyetujui asas dan tujuan PPTI serta memenuhi ketentuan organisasi yang diatur dalam AD/RT dan aturan organisasi PPTI lainnya.
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-16 reveal reveal-up delay-100">
          <div className="inline-flex p-1.5 bg-slate-100 rounded-[2rem] shadow-inner">
            <button 
              onClick={() => setActiveTab('perusahaan')}
              className={`flex items-center gap-2 px-8 py-4 rounded-[1.5rem] text-sm font-bold transition-all ${activeTab === 'perusahaan' ? 'bg-white text-blue-600 shadow-md scale-105' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <Building2 size={18} />
              Anggota Perusahaan
            </button>
            <button 
              onClick={() => setActiveTab('umum')}
              className={`flex items-center gap-2 px-8 py-4 rounded-[1.5rem] text-sm font-bold transition-all ${activeTab === 'umum' ? 'bg-white text-blue-600 shadow-md scale-105' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <UserCircle size={18} />
              Anggota Umum
            </button>
            <button 
              onClick={() => setActiveTab('kehormatan')}
              className={`flex items-center gap-2 px-8 py-4 rounded-[1.5rem] text-sm font-bold transition-all ${activeTab === 'kehormatan' ? 'bg-white text-blue-600 shadow-md scale-105' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <Award size={18} />
              Kehormatan
            </button>
          </div>
        </div>

        {/* Corporate Content */}
        {activeTab === 'perusahaan' && (
          <div className="space-y-12 animate-in fade-in zoom-in-95 duration-500">
            <div className="text-center max-w-2xl mx-auto">
              <p className="text-slate-500 font-medium italic">
                "Khusus untuk perusahaan yang bergerak di bidang Teknologi Informasi dengan tiga tingkatan kontribusi."
              </p>
            </div>
            <div className="grid lg:grid-cols-3 gap-8">
              {corporateTiers.map((tier, idx) => (
                <div key={idx} className={`${tier.color} rounded-[3rem] p-10 shadow-2xl flex flex-col h-full transform transition-all hover:-translate-y-4 hover:shadow-blue-200/50`}>
                  <div className="mb-8">
                    <h4 className={`text-2xl font-black ${tier.textColor} mb-2`}>{tier.name}</h4>
                    <div className="flex items-baseline gap-1">
                      <span className={`text-3xl font-black ${tier.textColor}`}>{tier.price}</span>
                      <span className={`text-sm font-medium ${tier.textColor} opacity-60`}>{tier.period}</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 space-y-6">
                    <div className={`h-px w-full bg-white/10`}></div>
                    <p className={`text-xs font-bold uppercase tracking-[0.2em] ${tier.accent}`}>Manfaat Eksklusif:</p>
                    {tier.benefits.map((benefit, bIdx) => (
                      <div key={bIdx} className="flex items-start gap-4">
                        <div className={`mt-1 p-1 rounded-full ${tier.accent} bg-white/10`}>
                          <CheckCircle2 size={14} />
                        </div>
                        <span className={`text-sm font-medium ${tier.textColor} opacity-90 leading-snug`}>{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => onRegister('perusahaan')}
                    className={`mt-12 w-full py-5 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${tier.name === 'Platinum' ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-xl shadow-blue-900/20' : 'bg-white text-slate-900 hover:bg-slate-50 shadow-lg'}`}
                  >
                    Daftar Paket {tier.name} <ArrowRight size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* General Content */}
        {activeTab === 'umum' && (
          <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid lg:grid-cols-5 gap-12 items-center">
              <div className="lg:col-span-3 space-y-8">
                <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-xs font-bold border border-blue-100">
                  <UserCircle size={16} /> Anggota Perorangan
                </div>
                <h4 className="text-4xl font-black text-slate-900">Anggota Umum</h4>
                <p className="text-slate-600 text-lg leading-relaxed">
                  Terbuka bagi seseorang yang memiliki pengalaman bidang TI, konsultan manajemen, atau lulusan baru dari jurusan Ekonomi, Manajemen, dan Teknologi Informasi.
                </p>
                
                <div className="flex items-center gap-6">
                  <div className="text-center bg-white p-6 rounded-3xl border-2 border-slate-100 shadow-xl min-w-[200px]">
                    <div className="text-xs text-slate-400 font-bold uppercase mb-1">Iuran Tahunan</div>
                    <div className="text-3xl font-black text-blue-600">Rp 200.000</div>
                  </div>
                  <button 
                    onClick={() => onRegister('umum')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 rounded-3xl font-bold shadow-xl shadow-blue-200 transition-all hover:scale-105"
                  >
                    Daftar Sekarang
                  </button>
                </div>
              </div>

              <div className="lg:col-span-2 space-y-4">
                <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/20 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-blue-600/40 transition-colors"></div>
                  <h5 className="text-xl font-bold mb-8 flex items-center gap-3">
                    <ShieldCheck className="text-blue-400" /> Manfaat Anggota:
                  </h5>
                  <ul className="space-y-8 relative z-10">
                    <li className="flex gap-4">
                      <div className="bg-white/10 p-3 rounded-2xl text-blue-400 h-12 w-12 flex items-center justify-center shrink-0">
                        <Award size={24} />
                      </div>
                      <div>
                        <div className="font-bold text-sm">Kartu Anggota Umum</div>
                        <div className="text-xs text-slate-400 mt-1">Identitas resmi sebagai bagian dari profesional PPTI Indonesia.</div>
                      </div>
                    </li>
                    <li className="flex gap-4">
                      <div className="bg-white/10 p-3 rounded-2xl text-blue-400 h-12 w-12 flex items-center justify-center shrink-0">
                        <Briefcase size={24} />
                      </div>
                      <div>
                        <div className="font-bold text-sm">Akses Proyek Kolaboratif</div>
                        <div className="text-xs text-slate-400 mt-1">Dapat mengikuti proyek milik anggota perusahaan PPTI (sesuai kompetensi).</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Honorary Content */}
        {activeTab === 'kehormatan' && (
          <div className="max-w-3xl mx-auto text-center animate-in fade-in zoom-in-95 duration-500">
            <div className="mb-10 inline-block relative">
              <div className="absolute inset-0 bg-blue-600 blur-2xl opacity-20 animate-pulse"></div>
              <div className="bg-blue-600 p-8 rounded-[2.5rem] text-white relative z-10">
                <Award size={64} strokeWidth={1.5} />
              </div>
            </div>
            <h4 className="text-4xl font-black text-slate-900 mb-6 tracking-tight">Anggota Kehormatan</h4>
            <div className="bg-green-100 text-green-700 px-10 py-4 rounded-full font-black text-xl inline-block mb-10 shadow-sm border border-green-200">
              Iuran: GRATIS
            </div>
            <div className="bg-slate-50 p-10 rounded-[3rem] border border-slate-200 text-left relative overflow-hidden">
               <div className="absolute -left-10 -top-10 text-slate-200/50">
                  <Award size={160} />
               </div>
               <div className="relative z-10">
                <h5 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Info className="text-blue-600" size={18} /> Kriteria Pengangkatan:
                </h5>
                <p className="text-slate-600 text-xl leading-relaxed font-medium">
                  "Diberikan kepada seseorang yang diangkat oleh organisasi, karena dinilai sangat berjasa dalam pengembangan profesi Teknologi Informasi di Indonesia."
                </p>
               </div>
            </div>
          </div>
        )}

        {/* Technical Partner Badge */}
        <div className="mt-20 py-10 border-t border-slate-100 reveal reveal-up delay-300">
          <div className="flex flex-col md:flex-row items-center justify-center gap-12 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
            <div className="flex items-center gap-3">
               <ShieldCheck className="text-blue-600" />
               <span className="font-bold text-slate-900">LSP : Komunikasi Informatika</span>
            </div>
            <div className="flex items-center gap-3">
               <Building2 className="text-blue-600" />
               <span className="font-bold text-slate-900">TUK Digital Business Indonesia</span>
            </div>
            <div className="flex items-center gap-3">
               <Percent className="text-blue-600" />
               <span className="font-bold text-slate-900">CaaS Business Unit</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MembershipBenefits;